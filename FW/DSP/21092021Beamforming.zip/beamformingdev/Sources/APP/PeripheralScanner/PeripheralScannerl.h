/*
 * PeripheralScannerl.h
 *
 *  Created on: 2 de mai de 2021
 *      Author: xiado
 */

#ifndef SOURCES_APP_PERIPHERALSCANNER_PERIPHERALSCANNERL_H_
#define SOURCES_APP_PERIPHERALSCANNER_PERIPHERALSCANNERL_H_

Void periodScanner(void );



#endif /* SOURCES_APP_PERIPHERALSCANNER_PERIPHERALSCANNERL_H_ */
