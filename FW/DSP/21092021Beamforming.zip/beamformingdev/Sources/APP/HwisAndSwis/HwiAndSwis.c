/*
* HwiAndSwis.c
* Author: Dong Xia
* @description
*
* Change Records:
*      >> (12/09/2021): Source file created
*
*/

/********************************************
* Include
********************************************/
#include <std.h>
#include <sem.h>
#include <csl_dma.h>
#include "../MailboxInstance.h"
#include "../../beamformType.h"

/********************************************
* Internal Function Declaration
********************************************/



/********************************************
* Internal Types and Variables
********************************************/

/********************************************
* External Variables
********************************************/
extern MBX_Obj MbSignalProcessor2SDWriter;
extern SEM_Obj SemHwi2SDWriter;
extern SEM_Obj SemDataParserCopyMem;
extern SEM_Obj semSigProcessorMemRdy;
extern SEM_Obj SemSDMemRdy;

/********************************************
* Functions
********************************************/
/*------------------------------------------------
* HWI_DmaCh0
* Hwi function for DMA CH0 interrupt
* DMA CH0 is used to transfer the data from SDRAM
* into MMC/SDHC card.
* When the DMA transfer FRAME BIT is set,
* the DMA transfer is ready, and a semaphore
* should be posted.
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (12/09/2021): Create the function
*----------------------------------------------*/
Void HWI_DmaCh0(Arg args){
    uint16_t var;
    //clear the interrput flag
    var = DMA_RGET(DMACSR0);
    //post the semaphore
    SEM_postBinary(&SemHwi2SDWriter);

}

/*------------------------------------------------
* HWI_DmaCh1
* HWI function for DMA CH1
* Channel 1 is used to transmit the data from MCBSP
* to SDRAM memory
* When the DMA transfer FRAME BIT is set,
* the DMA transfer is ready, and send a mail
* to SignalProcessor
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (16/09/2021): Create the function
*----------------------------------------------*/
Void HWI_DmaCh1(Arg args){



}

/*------------------------------------------------
* HWI_DmaCh2
* HWI function for DMA CH2
* Channel 2 is used to transmit the data from dataparser memory
* to SDRAM memory
* When the DMA transfer FRAME BIT is set,
* the DMA transfer is ready, and send a semaphore to data parser
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (18/09/2021): Create the function
*----------------------------------------------*/
Void HWI_DmaCh2(Arg args){
    uint16_t var;
    //clear the interrput flag
    var = DMA_RGET(DMACSR2);
    //post the semaphore
    SEM_postBinary(&SemDataParserCopyMem);

}


/*------------------------------------------------
* HWI_DmaCh3
* HWI function for DMA CH3
* Channel 3 is used to copy the data for signal processor
* from DARAM to SDRAM and SDRAM to DRAM
* When the DMA transfer FRAME BIT is set,
* the DMA transfer is ready, and send a Semaphore to
* signal processor
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (18/09/2021): Create the function
*----------------------------------------------*/
Void HWI_DmaCh3(Arg args){
    uint16_t var;
    //clear the interrput flag
    var = DMA_RGET(DMACSR3);
    //post the semaphore
    SEM_postBinary(&semSigProcessorMemRdy);

}


/*------------------------------------------------
* HWI_DmaCh4
* HWI function for DMA CH4
* Channel 4 is used to copy the data from processed
* signal block into cluster buffer
* from SDRAM to SDRAM
* When the DMA transfer FRAME BIT is set,
* the DMA transfer is ready, and send a Semaphore to
* sdwriter
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (18/09/2021): Create the function
*----------------------------------------------*/
Void HWI_DmaCh4(Arg args){
    uint16_t var;
    //clear the interrput flag
    var = DMA_RGET(DMACSR4);
    //post the semaphore
    SEM_postBinary(&SemSDMemRdy);

}
