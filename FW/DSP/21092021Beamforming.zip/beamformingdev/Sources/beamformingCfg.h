/*
 * beamformingCfg.h
 *
 *  Created on: 18 de set de 2021
 *      Author: xiado
 */

#ifndef SOURCES_BEAMFORMINGCFG_H_
#define SOURCES_BEAMFORMINGCFG_H_

#define CHANNEL_NO 3

//DO not modify the definition below.
#define MAX_CHANNEL_NO 32
#define ONE_CHANNEL_SIGNAL_BLK_SZ 512l
#define SAMPLING_FREQ 16000.0  // Unit: Hz


#if CHANNEL_NO > MAX_CHANNEL_NO
#error Channel no defined error!! No more than MAX_CHANNEL_NO.
#endif

#endif /* SOURCES_BEAMFORMINGCFG_H_ */
