/*
* ADCSPI.h
* Author: Dong Xia
* MCBSP configured as ADC SPI slave
*
* Change Records:
*      >> (16/09/2021): Head file Created
*
*/

#ifndef SOURCES_BSP_ADC_ADCSPI_H_
#define SOURCES_BSP_ADC_ADCSPI_H_
/********************************************
* Include
********************************************/
#include "../../beamformingCfg.h"

/********************************************
* Macro
********************************************/
#define IN_CLK_FREQ_MHZ 192

#define SAMPLING_RATE_HZ SAMPLING_FREQ

/********************************************
* Type definition
********************************************/


/********************************************
* Function prototype
********************************************/
void ADCDrvInit();









#endif /* SOURCES_BSP_ADC_ADCDRIVER_H_ */
