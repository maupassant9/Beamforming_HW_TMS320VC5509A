/*
* ADCSPI.c
* Author: Dong Xia
* MCBSP configured as ADC SPI slave
* Timer1 used to generate the conversion pulse
*
*
* Change Records:
*      >> (16/09/2021): Source file created
*
*/

/********************************************
* Include
********************************************/
#include <csl_timer.h>
#include <csl_mcbsp.h>
#include "ADCDriver.h"
#include "../../beamformType.h"


/********************************************
* Internal Function Declaration
********************************************/
static void Timer0Start(double period);
static void ADCMcbspAsSlave( void );



/********************************************
* Internal Types and Variables
********************************************/

/********************************************
* External Variables
********************************************/


/********************************************
* Functions
********************************************/
/*------------------------------------------------
* ADCDrvInit
* Initialize the ADC module:
* Configure the MCBSP to receive ADC data
* Configure the timer0 to generate the periodic
* timer.
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (16/09/2021): Create the function
*----------------------------------------------*/
void ADCDrvInit(){
    Timer0Start(1.0e6/SAMPLING_RATE_HZ);
    ADCMcbspAsSlave();

}

/*------------------------------------------------
* Timer1Init
* Initialize the timer1 to generate the pulse wave
*                                    |<->| Pulsewidth (us)
*            ___                      ___
*           |   |                    |   |
* ----------     --------------------     -------
*           |<------period(us)------>|
* Paras:
*  >> period : period in us
*  >> pulsewidth : pulse width in us
* Return:
*  >>
* Change Records:
*  >> (18/09/2021): Create the function
*----------------------------------------------*/
static void Timer0Start(double period){

    TIMER_Handle htimer;
    htimer = TIMER_open(TIMER_DEV0, 0);

    uint32_t periodInClk = (uint32_t)(period*IN_CLK_FREQ_MHZ);

    TIMER_Config timercfg;
    timercfg.prd = (periodInClk/16)-1;
    timercfg.tcr = 0x8e4;
    timercfg.prsc = 0x000f;

    TIMER_config(htimer, &timercfg);
    TIMER_start(htimer);
}


/*------------------------------------------------
* ADCMcbspAsSlave
* Configure the MCBSP as a SPI Slave device
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (20/09/2021): Create the function
*----------------------------------------------*/
static void ADCMcbspAsSlave( void ){
    MCBSP_Handle mcbsp2_handle;
        // The value for configure the register refered to MCBSP
    MCBSP_Config config_as_spi ={
        0x1000,  /*SPRC1: DLB RJUST CLKSTP(10) Rsvd DXENA ABIS RINTM RSYNCEER RFULL RRDY RRST */
        0x0200,  /*SPRC2: Rsvd FREE SOFT FRST_ GRST_ XINTM XSYNCEER XEMPTY XRDY XRST*/
        0x0020,  /*RCR1: Rsvd RFRLEN1 RWDLEN1 Rsvd*/
        0x0004,  /*RCR2: RPHASE RFRLEN2 RWDLEN2 RCOMPAND RFIG RDATDLY*/
        0x0020,  /*XCR1*/
        0x0024,//0x0000,  /*XCR2*/
        0x0f18,//0x0001,  /*SRGR1: FWID CLKGDV ??*/ 59
        0x3013,//0xb000,  /*SRGR2: GSYNC CLKSP CLKSM FSGM FPER??*/
        0x0000,  /*MCR1: Rsvd RMCME RPBBLK RPABLK RCBLK Rsvd RMCM*/
        0x0000,  /*MCR2: Rsvd XMCME XPBBLK XPABLK XCBLK XMCM*/
        0x050b,  /*PCR: Rsvd IDLE_EN XIOEN RIOEN FSXM FSRM CLKXM CLKRM*/
               /*     SCLKME CLKS_STAT DX_STAT FSXP FSRP CLKXP CLKRP*/

        0x0000,  /*RCERA*/
        0x0000,  /*RCERB*/
        0x0000,  /*RCERC*/
        0x0000,  /*RCERD*/
        0x0000,  /*RCERE*/
        0x0000,  /*RCERF*/
        0x0000,  /*RCERG*/
        0x0000,  /*RCERH*/

        0x0000,  /*XCERA*/
        0x0000,  /*XCERB*/
        0x0000,  /*XCERC*/
        0x0000,  /*XCERD*/
        0x0000,  /*XCERE*/
        0x0000,  /*XCERF*/
        0x0000,  /*XCERG*/
        0x0000   /*XCERH*/
    };

    /* Open MCBSP port 2*/
    mcbsp2_handle = MCBSP_open(MCBSP_PORT2,MCBSP_OPEN_RESET);
    //Configure the register of MCBSP port1
    MCBSP_config(mcbsp2_handle,&config_as_spi);
    //Start MCBSP sample rate generator
    MCBSP_start(mcbsp2_handle,MCBSP_SRGR_START,MCBSP_SRGR_DEFAULT_DELAY);
    //Enable MCBSP receiver
    MCBSP_start(mcbsp2_handle,MCBSP_RCV_START,10);
    //Enable MCBSP frame-sync logic of sample rate generator
    MCBSP_start(mcbsp2_handle,MCBSP_SRGR_FRAMESYNC,10);
}



