#define CMD0 0xc000
#define CMD55 0x8237
#define ACMD41 0x0629
#define CMD2 0x0402
#define CMD3 0x0203
#define CMD7 0x0307
#define CMD24 0xaa18
#define CMD17 0xa211
#define CMD7_DESELECT 0x0007
#define CMD16 0x0210
#define ACMD6 0x0206
#define CMD1 0x0601
#define CMD8 0x0208
#define CMD42 0x022a
#define CMD6 0x0206
#define CMD25 0xaa19
#define CMD12 0x030c


void CardInit(void);
void SendCommand(unsigned int command_index,unsigned int argument_high,unsigned int argument_low);
void GetResponse(int);
void CardIdentify(void);
//void INT_DisableGlobal(void);
void Delay(void);
unsigned int WriteDataToCard(unsigned int card_rca,unsigned int addr_high, unsigned int addr_low,unsigned int* buffer_ptr);
void ReadDataFromCard(unsigned int card_rca,unsigned int addr_high, unsigned int addr_low,unsigned int *buffer_ptr);
void SetTransMod(void);

unsigned int  WriteMultipleDataToCard(unsigned int card_rca,  \
                                      unsigned int addr_high, \
                                      unsigned int addr_low,  \
                                      unsigned int* buffer_ptr, \
                                      unsigned int num);
