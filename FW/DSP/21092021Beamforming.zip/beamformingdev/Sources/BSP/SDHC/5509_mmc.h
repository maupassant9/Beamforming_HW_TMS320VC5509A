/*
 * File name; 5509_mmc.h
 *-----------------------------------------
 * Header file for mmc of 5509 DSP
 *-----------------------------------------
 *Author; Dary
 *Date;   7-July-08
 *Email;  xiadong.us@gmail.com
 *-----------------------------------------*/
 
 /*=============================================*
  *         Modification     Record             *
  *
  *
  *=============================================*/
  
  
  volatile ioport unsigned int *MMCFCLK = (unsigned int *)0x4800;
  volatile ioport unsigned int *MMCCTL = (unsigned int *)0x4801;
  volatile ioport unsigned int *MMCCLK = (unsigned int *) 0x4802;
  volatile ioport unsigned int *MMCST0 = (unsigned int *) 0x4803;
  volatile ioport unsigned int *MMCST1 = (unsigned int *) 0x4804;
  volatile ioport unsigned int *MMCIE = (unsigned int *) 0x4805;
  volatile ioport unsigned int *MMCTOR = (unsigned int *) 0x4806;
  volatile ioport unsigned int *MMCTOD = (unsigned int *) 0x4807;
  volatile ioport unsigned int *MMCBLEN = (unsigned int *) 0x4808;
  volatile ioport unsigned int *MMCNBLK = (unsigned int *) 0x4809;
  volatile ioport unsigned int *MMCNBLC = (unsigned int *) 0x480A;
  volatile ioport unsigned int *MMCDRR = (unsigned int *) 0x480B;
  volatile ioport unsigned int *MMCDXR = (unsigned int *) 0x480C;
  volatile ioport unsigned int *MMCCMD = (unsigned int *) 0x480D;
  volatile ioport unsigned int *MMCARGL = (unsigned int *) 0x480E;
  volatile ioport unsigned int *MMCARGH = (unsigned int *) 0x480F;
  volatile ioport unsigned int *MMCRSP0 = (unsigned int *) 0x4810;
  volatile ioport unsigned int *MMCRSP1 = (unsigned int *) 0x4811;
  volatile ioport unsigned int *MMCRSP2 = (unsigned int *) 0x4812;
  volatile ioport unsigned int *MMCRSP3 = (unsigned int *) 0x4813;
  volatile ioport unsigned int *MMCRSP4 = (unsigned int *) 0x4814;
  volatile ioport unsigned int *MMCRSP5 = (unsigned int *) 0x4815;
  volatile ioport unsigned int *MMCRSP6 = (unsigned int *) 0x4816;
  volatile ioport unsigned int *MMCRSP7 = (unsigned int *) 0x4817;
  volatile ioport unsigned int *MMCDRSP = (unsigned int *) 0x4818;
  //ioport unsigned int * MMCCLK = (unsigned int *) 0x4c19;
  volatile ioport unsigned int * MMCCIDX= (unsigned int *) 0x481A;
 #define DevNum 1
