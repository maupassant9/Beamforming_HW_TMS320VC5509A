
/*Filename: sd.c
 *-----------------------------------
 * The source file for understanding MMC
 * How does it work and what the usages of 
 * such a 'huge' number of registers?
 * The way of accessing mmc is using csl 
 * from ti, which has ease the using of mmc.
 *------------------------------------
 *Author: Dary
 *Date:   6-July-08
 *Email:  Xiadong.us@gmail.com
 *Ver:    0.1
 *------------------------------------*/

/*===================================================
 *          Modification Records(Histroy)
 *6-7-08: Begin my program
 *
 *             
 *==================================================*/ 
//#include <stdio.h>
//#include <csl_mmc.h>  
#include <csl.h>          
#include <csl_pll.h>
#include "5509_mmc.h"
#include "sd.h"
#include "util.h"
#include <csl_mmc.h>
#include <csl_dma.h>
#include <sem.h>
#include "../../beamformType.h"


 
 // The value for configure the register refered to MCBSP
 unsigned int sd_config[8] ={
 0x0003, // MMCCTL = 0000,000-0,-01-00,0-0-1-1
         //          RSV--DMAEN-DATEG-RSV-WIDTH-CMDRST-DATRST
 0x0001, //MMCFCLK = 0000,000-0,-0000,0001
         //          RSV-IDLEEN-FDIV           FCLK = CPUCLK/(FCLK+1)=CPUCLK/1
 0x0300, //MMCCLK  = 0000,000-1,-0000,1001
         //          RSV-CLKEN-CDIV            MMCCLK = FCLK/(2*(CDIV+1))=FCLK/2
 0x0000, //MMCIE(MMCIM)= 0000,-0-0-0-0,-0-0-0-0,-0-0-0-0
         //  RSV-DATEG-DRRDY-DXRDY-RSV-CRCRS-CRCRD-CRCWR-TOUTRS-TOUTRD-RSPDNE-BSYDNE-DATDNE
         //---          fix               me                  ---
 0x0000, //MMCTOR = 0000,0000,-1111,1111
         //         RSV-TOR
 0xffff, //MMCTOD = 1111,1111,1111,1111
         //         TOD
 0x0200, //MMCBLEN = 0000,-0010,0000,0000   Note:This value must match the block length
         //          RSV-BLEN                    setting in the memory card.
 
 0x0001, //MMCNBLK = 0000,0000,0000,0001
         //          NBLK 
};

unsigned int response_buffer[9]={0,0,0,0,0,0,0,0,0};
typedef struct {
    unsigned int manufacturer_id;
    unsigned int application_id;
    unsigned long long product_name;
    unsigned int product_revision;
    unsigned long product_sn;
    unsigned int manufacturer_date;
} card_information_dt;
card_information_dt card_information;

//unsigned int card_rca = 0;
extern unsigned int card_rca;
unsigned long temp = 0;

static DMA_Handle myhdma;
static DMA_Config dmacfg = {
    0x0609,
    0x1006,
    0x0008,
    0,
    0,
    (DMA_AdrPtr)0x9018,
    0x0,
    4096, //16 clusters
    1,
    0,
    0,
    0,
    0
};


extern MMC_Handle sd_handle;
MMC_CardObj *card, cardalloc;
MMC_CardIdObj *cid, cardid;
MMC_CardCsdObj *csd, cardcsd;
SD_CardCsdObj *sdcsd, sdcardcsd;

extern SEM_Obj SemHwi2SDWriter;


MMC_SetupNative Init = {
    0,   /* disable DMA for data read/write                    */
    0,   /* Set level of edge detection for DAT3 pin           */
    0,   /* Determines if MMC goes IDLE during IDLE instr      */
    0,   /* Memory clk reflected on CLK Pin                    */
    7,   /* CPU CLK to MMC function clk divide down            */
    5,   /* MMC function clk to memory clk divide down         */
    0,   /* No. memory clks to wait before response timeout    */
    0,   /* No. memory clks to wait before data timeout        */
    512, /* Block Length must be same as CSD                   */
};



/*========================Functions========================*/
void CardInit(void)
{
    //Step1: Place MMC controller in reset state
    *MMCCTL = 0x0007;

    //Step2: Write to other register and other bits in MMCCTL
    *MMCCTL  = 0x0003; //enable dmaen 0x0100
    *MMCFCLK = 0x3b;  //0x3b; //sd_config[1];//set as /60 first and then set to higher freq
    *MMCCLK = sd_config[2];
    *MMCIE = sd_config[3];
    *MMCTOR = sd_config[4];
    *MMCTOD = sd_config[5];
    *MMCBLEN = sd_config[6];
    *MMCNBLK = sd_config[7];
    
    //Step3: Release the MMC controller by clear the last two bits
    *MMCCTL = 0x104;
    
    *MMCCLK |= 0x0100; //enable clken

    //should also init the dma for transfer
    myhdma = DMA_open(DMA_CHA0,0);
}   

void CardIdentify(void)
{
    SendCommand(CMD0,0,0);
    GetResponse(0);
    
    SendCommand(CMD8,0x0000,0x01aa);
    GetResponse(1);
    
    //Send CMD55 Indicate that the next command is a application
    //specific command.
    SendCommand(CMD55,0,0);
    GetResponse(1);
    
    //Delay();
    Delay();
    
    SendCommand(ACMD41,0x40ff,0x8000);
    GetResponse(1);
	Delay();
	Delay();
    while(!(response_buffer[7] & 0x8000))
    {
            SendCommand(CMD55,0,0);
            GetResponse(1);
            Delay();
            SendCommand(ACMD41,0x40ff,0x8000);
            GetResponse(1); 
            Delay();
    }
   
    //Send CMD2 : Get the card's CID number
    SendCommand(CMD2,0x0000,0x0000);
    GetResponse(1);
    
    //Send CMD3: Card Response with new RCA
    //And Card Go to Data Transfer Mode
    SendCommand(CMD3,0x0000,0x0000);
    GetResponse(1);
    card_rca = response_buffer[7];
    Delay();
}



void SendCommand(unsigned int command_index,unsigned int argument_high,unsigned int argument_low)
{
    // Load argument register
    *MMCARGH = argument_high;
    *MMCARGL = argument_low;
    
    *MMCCMD = command_index;
}

void GetResponse(int with_response)
{
    
   unsigned int i;
        
    while(1)
    {
        temp = (*MMCST0) & 0x0094;
        if ((temp&0x10) || (!(temp&0x04))) break;
    }
    //!!!!The delay here can't be too long, and neither 
    //be too short, about 8000 cpu clock, I still don't know why
    asm(" NOP");
    for(i = 0; i < 700; i++);
    asm(" NOP");

    if(with_response)
    {
        response_buffer[8] = *MMCCIDX;
        response_buffer[0] = *MMCRSP0;
        response_buffer[1] = *MMCRSP1;
        response_buffer[2] = *MMCRSP2;
        response_buffer[3] = *MMCRSP3;
        response_buffer[4] = *MMCRSP4;
        response_buffer[5] = *MMCRSP5;
        response_buffer[6] = *MMCRSP6;
        response_buffer[7] = *MMCRSP7;
    }
}    

/*Function: WriteDataToCard
 *----------------------------------
 *Send 512 byte data to card.
 *1. Use cmd7 to select one card, and put it into transfer mode.
 *2. Write data.
 *-----------------------------------
 *Author: Dary
 *Date:   11-Jul-08
 *Email:  Xiadong.us@gmail.com
 *------------------------------------*/
 //--------------------fix me---------------------------------------
unsigned int  WriteDataToCard(unsigned int card_rca,
                              unsigned int addr_high,
                              unsigned int addr_low,
                              unsigned int* buffer_ptr)
 {
     int i,buffer[32];
     //int *ptr;
     
     *MMCNBLK = 1;
     //ptr = buffer;
     
     SendCommand(CMD24,addr_high,addr_low);
     GetResponse(1);
     for(i = 1; i <= 256; i++)
     {
         //Don't know why can't change the position!!!!!
         while((*(MMCST0)&0x0200) != 0x0200);
         *(MMCDXR) = *(buffer_ptr++);
     }
     while(!((*MMCST0)&0x0001));
     return 1;
}


//========================================
// FunctionName: ReadDataFromCard
//----------------------------------------

void ReadDataFromCard(unsigned int card_rca,
                      unsigned int addr_high,
                      unsigned int addr_low,
                      unsigned int* buffer_ptr)
{
     
     unsigned int *ptr = buffer_ptr;
     int i = 256;
     *MMCNBLK = 1;

     //Read data from Card
     SendCommand(CMD17,addr_high,addr_low);
     GetResponse(0);

     for(i = 0; i < 256; i++)
     {
         while(!((*MMCST0)&0x0400));
         *(ptr++) = *(MMCDRR);
     }
}


void SetTransMod (void)
{
     //Select Card
     SendCommand(CMD7,card_rca,0x0000);
     while(!((*MMCST0)&0x0002));
     GetResponse(1);
     
    
     //Set as 4-bits mode
     SendCommand(CMD55,card_rca,0);
     GetResponse(0);
     
     SendCommand(ACMD6,0x0000,0x0002);
     GetResponse(1);

     //Set as High Speed.
     SendCommand(CMD6,0x8000,0x0001);
     GetResponse(1);


     //Set Block length in SD card using CMD16(no need to do this for SDHC, since you want
     // 512byte to be write or read
     *MMCBLEN = 0x0200;
     //SendCommand(CMD16,0x0000,0x0200);
     //GetResponse(1);
     *MMCFCLK = sd_config[1]; //set to higher frequency
}




 void Delay(void)
{
  unsigned int m = 0xffff;
  
  for(m = 0x00ff; m > 0; m--);

}

// //写一簇数据
//unsigned int  WriteMultipleDataToCard(unsigned int card_rca,  \
//                                      unsigned int addr_high, \
//                                      unsigned int addr_low,  \
//                                      unsigned int* buffer_ptr, \
//                                      unsigned int num)
// {
//     int i;
//
//     *MMCNBLK = num;
//
//     SendCommand(CMD25,addr_high,addr_low);
//     GetResponse(0);
//     for(i = 1; i <= 256*num; i++)
//     {
//         //Don't know why can't change the position!!!!!
//         while((*(MMCST0)&0x0200) != 0x0200);
//         *(MMCDXR) = *(buffer_ptr++);
//     }
//
//	 SendCommand(CMD12,0x0000,0x0000);
//     //Inidicate memory start address
//     //check whether data transmit ready
//     while(!((*MMCST0)&0x0002));
//	 GetResponse(0);
//     return 1;
//}


  //写一簇数据
 unsigned int  WriteMultipleDataToCard(unsigned int card_rca,  \
                                       unsigned int addr_high, \
                                       unsigned int addr_low,  \
                                       unsigned int* buffer_ptr, \
                                       unsigned int num)
  {
      int i; uint32_t j =0xffffffff;
      uint32_t bufAddr = ((uint32_t)buffer_ptr)<<1;
      bufAddr += 2;

      *MMCNBLK = num;

      SendCommand(CMD25,addr_high,addr_low);
      GetResponse(0);
      //clear the mmcst0
      dmacfg.dmacssal = (DMA_AdrPtr)(bufAddr&0xffff);
      dmacfg.dmacssau = (uint16_t)((bufAddr&0xffff0000)>>16);
      dmacfg.dmacen = num*256-1;
      DMA_config(myhdma, &dmacfg);

      while((*(MMCST0)&0x0200) != 0x0200);
      *(MMCDXR) = *(buffer_ptr);
      DMA_start(myhdma);
      //*MMCST0 &= ~0x0200;

      //wait for dma transfer finished
      //while(!DMA_FGETH(myhdma, DMACSR, FRAME));
      //use a semaphore to do that
      SEM_pendBinary(&SemHwi2SDWriter, SYS_FOREVER);
      //DMA_close(myhdma);

      SendCommand(CMD12,0x0000,0x0000);
      //Inidicate memory start address
      //check whether data transmit ready
      while(!((*MMCST0)&0x0002));
      GetResponse(0);
      return 1;
 }

