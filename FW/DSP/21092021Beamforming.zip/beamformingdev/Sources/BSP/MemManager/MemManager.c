/*
* MemManger.c
* Author: Dong Xia
* @description
*
* Change Records:
*      >> (13/09/2021): Source file created
*
*/

/********************************************
* Include
********************************************/
#include <sem.h>
#include "MemManager.h"
#include "../../beamformType.h"


/********************************************
* Internal Function Declaration
********************************************/
static void MemManagerMark(uint16_t pos, Bool isAllocate);
static int16_t MemManagerSearchInOneUnit(int pos);
static int16_t MemManagerSearch();


/********************************************
* Internal Types and Variables
********************************************/
//when the bit is 1: allocated, 0 as free to use
static uint16_t memAllocTable[MEM_ALLOC_TABLE_SZ];
#pragma DATA_SECTION(memBlk, "mem_block_section");
static uint16_t memBlk[MEM_BLOCK_LEN*MEM_BLOCK_NO];
//#pragma DATA_ALIGN(memBlk,0x1000);
//Resource Locker for memeory table
extern SEM_Obj LockerMemAllocTable;
/********************************************
* External Variables
********************************************/


/********************************************
* Functions
********************************************/
/*------------------------------------------------
* MemManagerInit
* Initialize the memery manager
* Clear the memory allocation table
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (13/09/2021): Create the function
*----------------------------------------------*/
void MemManagerInit(void){

    int cnt;
    //initialize the table
    for(cnt = 0; cnt < MEM_ALLOC_TABLE_SZ; cnt++){
        memAllocTable[cnt] = 0x0;
    }

    //post the semaphore
    SEM_postBinary(&LockerMemAllocTable);
}

/*------------------------------------------------
* MemManagerMalloc
* Malloc a piece of block or piecese of consecutive blocks
* Paras:
*  >> :
* Return:
*  >> the address of the block if successfully allocated
*     0, if not successfully allocated
* Change Records:
*  >> (13/09/2021): Create the function
*----------------------------------------------*/
uint32_t MemManagerMalloc(){

    int16_t blkpos;

    blkpos = MemManagerSearch();
    if(blkpos == -1) return 0;

    //mark in the mem allocation table as used
    MemManagerMark(blkpos, TRUE);

    return (uint32_t)((uint32_t)memBlk + MEM_BLOCK_LEN*blkpos);
}

/*------------------------------------------------
* MemManagerFree
* free a piece of block
* Paras:
*  >> addr: address to be freed
* Return:
*  >> the address of the block if successfully allocated
*     0, if not successfully allocated
* Change Records:
*  >> (13/09/2021): Create the function
*----------------------------------------------*/
void MemManagerFree(uint32_t addr){
    //find the position of corresponding place in memory allocation table
    uint16_t blkpos = (addr - (uint32_t)memBlk)/MEM_BLOCK_LEN;

    MemManagerMark(blkpos, FALSE);
}


/*------------------------------------------------
* MemManagerSearch
* Search in memory allocate table if there is any
* space required by user
* Paras:
*  >> blocksz: size of the block needed
*  >> :
* Return:
*  >> bit position in the of the first block, start from 0
*     if no memory block is avaliable, return -1
* Change Records:
*  >> (13/09/2021): Create the function
*----------------------------------------------*/
static int16_t MemManagerSearch(){

    int cnt, hasFree = FALSE;
    for(cnt = 0; cnt < MEM_ALLOC_TABLE_SZ; cnt++){

        if(memAllocTable[cnt] != 0xffff){
            //if there is any space can be allocated
            hasFree = TRUE;
            break;
        }
    }

    //check the cnt value
    if(hasFree){
        return MemManagerSearchInOneUnit(cnt)+(cnt<<4);
    }

    return -1;
}

/*------------------------------------------------
* MemManagerSearchInOneWord
* The memory is organized in units, search in one unit
* Paras:
*  >> pos: the unit position that should be searched
*  >> :
* Return:
*  >> bit position in the of the first block, start from 0
*     if no memory block is avaliable, return -1
* Change Records:
*  >> (13/09/2021): Create the function
*----------------------------------------------*/
static int16_t MemManagerSearchInOneUnit(int pos){
    int cnt = 0, valToBeVerify = memAllocTable[pos];
    int valVerify = 0x01;

    for(;cnt < 16; cnt++){
        if((valToBeVerify & valVerify) == 0x0){
            return cnt;
        }
        valVerify = valVerify << 1;
    }

    return -1;
}


/*------------------------------------------------
* MemManagerMark
* Mark in the memory allocation table, use semaphore
* to protect the critical area.
* Paras:
*  >> pos : the position in the memory allocation table
*  >> isAllocate: allocate or free
* Return:
*  >>
* Change Records:
*  >> (13/09/2021): Create the function
*----------------------------------------------*/
static void MemManagerMark(uint16_t pos, Bool isAllocate){
    int16_t posUnit = pos/16;
    int16_t posBit = pos%16;

    //check if the memory table is in use or not
    SEM_pendBinary(&LockerMemAllocTable, SYS_FOREVER);
    if(isAllocate){
        memAllocTable[posUnit] |= (0x01<<posBit);
    } else {
        memAllocTable[posUnit] &= ~(0x01<<posBit);
    }
    //after use the table, release the resource
    SEM_postBinary(&LockerMemAllocTable);
}



/*------------------------------------------------
* MemManagerGetChannelPntsInBlock
* Get the total number of channel pnts in one block
* for a given channel and first channel id
* Paras:
*  >> chID : channel to analyse
*  >> firstChID: the channel id of the first pnt in block
*  >> chNum: number of channel inside block
* Return:
*  >> uint16_t: number of pnts of this channel in block
* Change Records:
*  >> (16/09/2021): Create the function
*----------------------------------------------*/
uint16_t MemManagerGetChannelPntsInBlock(
        uint16_t chID,
        uint16_t firstChID,
        uint32_t chNum){

    uint32_t factor = MEM_BLOCK_LEN/chNum;
    uint32_t cmpBlockSz = factor*chNum;

    //get the distance from the firstChID
    //to the chID that we need to check
    uint32_t dist = chNum - firstChID + chID;

    if(cmpBlockSz + dist < MEM_BLOCK_LEN){
        return factor+1;
    } else {
        return factor;
    }
}
