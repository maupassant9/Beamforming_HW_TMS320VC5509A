/*
 * MemManager.h
 *
 *  Created on: 13 de set de 2021
 *      Author: xiado
 */

#ifndef SOURCES_BSP_MEMMANAGER_MEMMANAGER_H_
#define SOURCES_BSP_MEMMANAGER_MEMMANAGER_H_
#include "../../beamformType.h"
#include "../../beamformingCfg.h"

#define MEM_BLOCK_LEN (ONE_CHANNEL_SIGNAL_BLK_SZ) //size in words

//#define MEM_INIT_ADDR 0x300000l
#define MEM_BLOCK_NO 480 //all CE1 space, should be the size of
#define MEM_ALLOC_TABLE_SZ MEM_BLOCK_NO/16

void MemManagerInit(void);
uint32_t MemManagerMalloc();
uint16_t MemManagerGetChannelPntsInBlock(
        uint16_t chID,
        uint16_t firstChID,
        uint32_t chNum);
void MemManagerFree(uint32_t addr);

#endif /* SOURCES_BSP_MEMMANAGER_MEMMANAGER_H_ */
