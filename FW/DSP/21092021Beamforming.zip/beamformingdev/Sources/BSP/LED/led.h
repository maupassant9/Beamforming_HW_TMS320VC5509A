/*
* led.h
* Author: Dong Xia
* Led abrastration structure.
*
* Change Records:
*      >> (02/05/2021): created
*
*/

#ifndef SOURCES_BSP_LED_LED_H_
#define SOURCES_BSP_LED_LED_H_
/********************************************
* Include
********************************************/
#include "../../beamformType.h"

/********************************************
* Macro
********************************************/
//number of LEDs
#define LED_NUM 1
//#define
//#define
//#define

/********************************************
* Type definition
********************************************/
// LED mode:
// * user controlled mode: set on or off by user
// * blink mode: user set frequency and some period service
//               should set on and off led accordingly.
enum ledMode_t {
    LED_MODE_USER_DEFINED = 0,
    LED_MODE_BLINK
};

enum ledState_t{
    LED_ON = 0,
    LED_OFF
};




/********************************************
* Function prototype
********************************************/
void bspLedInit( void );
void bspLedWrite(uint32_t ledID, enum ledState_t state);
void bspExitBlinkMode(uint32_t ledID);
void bspLedToggle(uint8_t ledId);
void bspSetFreq(uint32_t ledID, uint32_t freq_in_tick);
//update the state of LED depending on frequency setting
//* This function should only be called inside a periodic
//  time tick! DO NOT USE IT in other mode
void bspLedUpdateAll();


#endif /* SOURCES_BSP_LED_LED_H_ */
