/*
 *File name: init.h
 *--------------------------
 * Author: Xiadong
 * Create time: 10-Apr-2009
 * Email:  xiadong.cn@gmail.com
 *---------------------------*/
 
 //===========================================
 // This file is a part of SimpFat project,  //
 // Used to Init SimpleFat.                  //
 // Main data structure here are following   //
 //                                          //
 //     DISK_HANDLER_FT----Contain all the   //
 //               neccessary function pointer//
 //               BPB structure, and other   //
 //             disk information for handling//
 //               the disk.                  //
 //==========================================//
#include "com.h"
//定义各个缓冲区的大小，用于缓冲FAT表数据，
//缓冲采样数据信息，缓冲目录项信息，和一些临时信息。
#define BUFFER_SIZE 1024

//文件系统BPB信息
// #define SEC_PER_CLU   16
// #define HIDDEN_CLUSTER 8192
// #define RSVD_SEC     32
// #define TOTAL_CLU    1959014 //----FIXME----
// #define FAT_SZ       15308 //---FIXME---
//
//
//#define BYTS_PER_SEC 512
//
//#define BYTS_PER_CLU 8192
//#define FAT_CONTENT_PER_SEC 128
//#define FIRST_DATA_SEC   38840
//#define FDT_NUM 10


//文件系统BPB信息
//Disk 2_____4G old
/* #define SEC_PER_CLU   8
 #define HIDDEN_CLUSTER 0
 #define RSVD_SEC     32
 #define TOTAL_CLU    736000 //----FIXME----
 #define FAT_SZ       5744 //---FIXME---  


#define BYTS_PER_SEC 512

#define BYTS_PER_CLU 4096
#define FAT_CONTENT_PER_SEC 128
#define FIRST_DATA_SEC   11520
#define FDT_NUM 10
*/

//Disk 3_____4G Turbo
#define BYTS_PER_SEC 512 //字节/扇区
#define SEC_PER_CLU   16  // 扇区/簇

#define RSVD_SEC     490   //保留扇区
#define TOTAL_CLU    493312 //----FIXME----//总簇数
#define FAT_SZ       3851 //---FIXME--- //FAT大小
#define HIDDEN_CLUSTER 128 //隐藏扇区
#define BYTS_PER_CLU (SEC_PER_CLU*BYTS_PER_SEC) //字节/簇
#define FAT_CONTENT_PER_SEC (BYTS_PER_SEC/4) //
#define FIRST_DATA_SEC   ((FAT_SZ*2)+RSVD_SEC+HIDDEN_CLUSTER)

#define FDT_NUM 10     

//======================================================
// Initialize Fat file system
//  10-Apr-09
//======================================================
void FatInit();

void CanonicalToDir(uchar_dt *dest, uchar_dt *src);

bool_dt AddFdtContent();

bool_dt ApplyFreeSector();

void FlushCluster(ulong_dt);

void Err();
bool_dt CreateFile(uchar_dt * file_name_ucp);
bool_dt AppendFile(uint_dt * append_content);
