/*
* SDWriter.h
* Author: Dong Xia
* @description
*
* Change Records:
*      >> (11/09/2021): Head file Created
*
*/

#ifndef SOURCES_APP_SDWRITER_SDWRITER_H_
#define SOURCES_APP_SDWRITER_SDWRITER_H_
/********************************************
* Include
********************************************/


/********************************************
* Macro
********************************************/


/********************************************
* Type definition
********************************************/


/********************************************
* Function prototype
********************************************/
Void SDWriter( Arg id_arg );





#endif /* SOURCES_APP_SDWRITER_SDWRITER_H_ */
