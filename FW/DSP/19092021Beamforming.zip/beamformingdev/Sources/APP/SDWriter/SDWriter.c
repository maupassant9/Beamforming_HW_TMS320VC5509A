/*
* SDWriter.c
* Author: Dong Xia
* @description
*
* Change Records:
*      >> (11/09/2021): Source file created
*
*/

/********************************************
* Include
********************************************/
#include <std.h>
#include <clk.h>
#include <idl.h>
#include <log.h>
#include <sem.h>
#include <swi.h>
#include <tsk.h>
#include <csl_std.h>
#include <csl_dma.h>
#include "../MailboxInstance.h"
#include "../../beamformType.h"
#include "../../BSP/MemManager/MemManager.h"
#include "../../BSP/FastFat/fat.h"

/********************************************
* Internal Function Declaration
********************************************/
#define MAX_CLUSTER_NUM (1024l*25l) //100MB


#define CLUSTER_SZ_IN_WORD (BYTS_PER_SEC*SEC_PER_CLU/2)
/********************************************
* Internal Types and Variables
********************************************/
char filename[8];
#pragma DATA_SECTION(ClusterBuf, "sdbuf");
static uint16_t ClusterBuf[CLUSTER_SZ_IN_WORD];


/********************************************
* External Variables
********************************************/
extern SEM_Obj SemSDMemRdy;
Uchar * GenerateFileName();

/********************************************
* Functions
********************************************/
Void APP_TskSDWriter( Arg id_arg ){
    MBMsg_t msg;
    uint32_t clusterbufpos = 0;
    uint32_t clusterSz = 0;
    uint32_t addr;

    TSK_sleep(1000);

    FatInit();

    //DMA configuration for memory copy
      DMA_Handle sdMemCpy = DMA_open(DMA_CHA4, 0);
      DMA_Config sdMemCpyCfg = {
          0x0409, //DMACSDP
          0x5000, //DMACCR
          0x0008,
          0,
          0,
          0,
          0,
          ONE_CHANNEL_SIGNAL_BLK_SZ, //one block size
          1,
          0,
          0,
          0,
          0
      };

    while(1){
        //wait for mailbox to write mmc
        MBX_pend(&MbSignalProcessor2SDWriter, &msg, SYS_FOREVER);

        //transfer the data from resvd msg to clusterbuf
        addr = ((uint32_t)ClusterBuf)+
                clusterbufpos*ONE_CHANNEL_SIGNAL_BLK_SZ;
        sdMemCpyCfg.dmacdsal = (DMA_AdrPtr)((addr<<1)&0xffff);
        sdMemCpyCfg.dmacdsau = (uint16_t)((addr>>15)&0xffff);
        addr = msg.addr;
        sdMemCpyCfg.dmacssal = (DMA_AdrPtr)((addr<<1)&0xffff);
        sdMemCpyCfg.dmacssau = (uint16_t)((addr>>15)&0xffff);
        DMA_config(sdMemCpy, &sdMemCpyCfg);
        DMA_start(sdMemCpy);

        //pend on semaphore
        SEM_pendBinary(&SemSDMemRdy, SYS_FOREVER);

        //free the memory block
        MemManagerFree(msg.addr);
        clusterbufpos++;
        if(clusterbufpos == CLUSTER_SZ_IN_WORD/ONE_CHANNEL_SIGNAL_BLK_SZ){
            clusterbufpos = 0;
            if(clusterSz == 0){
                CreateFile(GenerateFileName());
            }
            AppendFile(ClusterBuf);
            bspLedToggle(0);
            clusterSz++;
            if(clusterSz == MAX_CLUSTER_NUM){
                clusterSz = 0;
            }
        }

    }
}


/*------------------------------------------------
* GenerateFileName
* Generate  a file name for the file
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (16/09/2021): Create the function
*----------------------------------------------*/
Uchar * GenerateFileName()
{
    int temp;
    //get a name for newly created file
    static int file_num = 0;
    file_num++;
    static Uchar file_name[12] = {0x20,0x20,0x20,0x20,0x20,0x20,
                                  0x20,0x20,0x20,0x20,0x20,0x20};

    file_name[0] = file_num/1000;
    temp = file_num - (file_name[0] * 1000);
    file_name[1] = temp/100;
    temp -= file_name[1]*100;
    file_name[2] = temp/10;
    temp -= file_name[2]*10;
    file_name[3] = temp;

    for(temp = 0; temp < 4; temp++)
    {
        file_name[temp] += 0x30;
    }

    return file_name;

}



