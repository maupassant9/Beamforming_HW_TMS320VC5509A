/*
* HwiAndSwis
* Author: Dong Xia
* @description
*
* Change Records:
*      >> (11/09/2021): Head file Created
*
*/


#ifndef SOURCES_APP_HWISANDSWIS_HWIANDSWIS_H_
#define SOURCES_APP_HWISANDSWIS_HWIANDSWIS_H_
/********************************************
* Include
********************************************/


/********************************************
* Macro
********************************************/


/********************************************
* Type definition
********************************************/


/********************************************
* Function prototype
********************************************/
Void HWI_DmaCh0(Arg args);

Void HWI_DmaCh1(Arg args);

Void HWI_DmaCH2(Arg args);




#endif /* SOURCES_APP_HWISANDSWIS_HWIANDSWIS_H_ */
