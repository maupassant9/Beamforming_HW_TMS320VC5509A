/*
 * uart.h
 *
 *  Created on: 18 de set de 2021
 *      Author: xiado
 */

#ifndef SOURCES_APP_UART_UART_H_
#define SOURCES_APP_UART_UART_H_





#endif /* SOURCES_APP_COMMUNICATOR_UART_H_ */
