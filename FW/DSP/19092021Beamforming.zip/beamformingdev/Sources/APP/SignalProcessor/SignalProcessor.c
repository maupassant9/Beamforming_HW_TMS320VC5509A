/*
* SignalProcessor.c
* Author: Dong Xia
* The data sent to sd writer is as follow:
* /subBlock1/subBlock2/subBlock3/..../
* subBlock has the fixed size of 256 WORDs
* Change Records:
*      >> (11/09/2021): Source file created
*
*/

/********************************************
* Include
********************************************/
#include <std.h>
#include <clk.h>
#include <idl.h>
#include <log.h>
#include <sem.h>
#include <swi.h>
#include <tsk.h>
#include <mbx.h>
#include <csl_dma.h>
#include "../MailboxInstance.h"
#include "../../BSP/MemManager/MemManager.h"
#include "../../beamformType.h"
#include "SignalProcessor.h"

/********************************************
* Internal Function Declaration
********************************************/



/********************************************
* Internal Types and Variables
********************************************/

/********************************************
* External Variables
********************************************/
#pragma DATA_SECTION(histSignal, "history_signal_section");
uint16_t histSignal[MAX_CHANNEL_NO][FILTER_ORDER];

#pragma DATA_SECTION(filterWorkingArea, "filter_working_area_section");
uint16_t filterWorkingArea[FILTER_ORDER+FILTER_WORKING_AREA_SZ];
uint16_t filterResultArea[FILTER_WORKING_AREA_SZ];

extern SEM_Obj semSigProcessorMemRdy;

/********************************************
* Functions
********************************************/
Void APP_TskSignalProcessor( Arg id_arg ){

    MBMsg_t msg;
    uint16_t *pmem;
    uint16_t i;
    uint32_t addr = (uint32_t)(&filterWorkingArea[FILTER_ORDER]);

    //init the hist memory
    pmem = &(histSignal[0][0]);
    for(i = 0; i < FILTER_ORDER*MAX_CHANNEL_NO; i++){
        *pmem++ = 0;
    }

    DMA_Handle sigHdma = DMA_open(DMA_CHA3,0);
    //SDRAM -- DARAM: from Mem block to filterWorkingArea
    DMA_Config sighdmaCfg1 = {
        0xA349, //DMACSDP
        0x5000, //DMACCR
        0x0008,
        0, 0, 0, 0,
        FILTER_WORKING_AREA_SZ, //element number
        1, 0, 0, 0, 0
    };
    sighdmaCfg1.dmacdsal = (DMA_AdrPtr)((addr<<1)&0xffff);
    sighdmaCfg1.dmacdsau = (uint16_t)((addr>>15)&0xffff);

    addr = (uint32_t)filterResultArea;
    //DARAM -- SDRAM: from filterWorkingArea to MemBlock
    DMA_Config sighdmaCfg2 = {
        0xA545, //DMACSDP
        0x5000, //DMACCR
        0x0008,
        0, 0, 0, 0,
        FILTER_WORKING_AREA_SZ, //16 clusters
        1, 0, 0, 0, 0
    };
    sighdmaCfg2.dmacssal = (DMA_AdrPtr)((addr<<1)&0xffff);
    sighdmaCfg2.dmacssau = (uint16_t)((addr>>15)&0xffff);

    while(1){
        //wait for mailbox
        MBX_pend(&MbDataParser2SignalProcessor, &msg, SYS_FOREVER);
        //configure the source addr and then transfer the data
        // to filter working area
        sighdmaCfg1.dmacssal = (DMA_AdrPtr)((msg.addr<<1)&0xffff);
        sighdmaCfg1.dmacssau = (uint16_t)((msg.addr >> 15)&0xffff);
        DMA_config(sigHdma, &sighdmaCfg1);
        DMA_start(sigHdma);
        SEM_pendBinary(&semSigProcessorMemRdy, SYS_FOREVER);
        ///////////////////////////////////////////////////
        //    HERE you will try to process the signal    //
        ///////////////////////////////////////////////////
        //just to copy the data from orignal signal to processed signal
        for(i = 0; i < FILTER_WORKING_AREA_SZ; i++){
            filterResultArea[i] = filterWorkingArea[FILTER_ORDER+i];
        }



        //////////////////////////////////////////////////
        //    Here end of signal processing             //
        //////////////////////////////////////////////////

        //When you finished the signal processing, copy back the data
        //1. you need to copy the last number of signal to the history signal
        for(i = 0; i < FILTER_ORDER; i++){
            histSignal[msg.firstChannelID][i] = filterWorkingArea[FILTER_WORKING_AREA_SZ+i];
        }
        //2. you need to copy the result from filter result area into sdram
        sighdmaCfg2.dmacdsal = (DMA_AdrPtr)((msg.addr<<1)&0xffff);
        sighdmaCfg2.dmacdsau = (uint16_t)((msg.addr >> 15)&0xffff);
        DMA_config(sigHdma, &sighdmaCfg2);
        DMA_start(sigHdma);
        SEM_pendBinary(&semSigProcessorMemRdy, SYS_FOREVER);

        MBX_post(&MbSignalProcessor2SDWriter, &msg, SYS_FOREVER);
    }
}




