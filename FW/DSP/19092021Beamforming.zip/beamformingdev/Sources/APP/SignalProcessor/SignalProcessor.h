/*
* FileName: SignalProcessor.h
* Author: Dong Xia
* @description
*
* Change Records:
*      >> (11/09/2021): Head file Created
*
*/

#ifndef SOURCES_APP_SIGNALPROCESSOR_SIGNALPROCESSOR_H_
#define SOURCES_APP_SIGNALPROCESSOR_SIGNALPROCESSOR_H_
/********************************************
* Include
********************************************/
#include "../../BSP/MemManager/MemManager.h"

/********************************************
* Macro
********************************************/
#define FILTER_ORDER 100
#define FILTER_WORKING_AREA_SZ ONE_CHANNEL_SIGNAL_BLK_SZ


/********************************************
* Type definition
********************************************/


/********************************************
* Function prototype
********************************************/
Void APP_TskSignalProcessor( Arg id_arg );





#endif /* SOURCES_APP_SIGNALPROCESSOR_SIGNALPROCESSOR_H_ */
