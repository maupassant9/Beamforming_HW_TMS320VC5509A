/*
* DataParser.c
* Author: Dong Xia
* The data resvd here is organized as follow in a block of memory:
*     /CH1/CH2/CH3/CH4/..../CH1/CH2/......
* word: 0   1   2   3       N   N+1
* When one block is filled, send back to the signal processor
* Change Records:
*      >> (11/09/2021): Source file created
*
*/

/********************************************
* Include
********************************************/
#include <std.h>
#include <clk.h>
#include <idl.h>
#include <log.h>
#include <sem.h>
#include <swi.h>
#include <tsk.h>
#include <csl_dma.h>
#include "../MailboxInstance.h"
#include "../../BSP/MemManager/MemManager.h"
#include "../../beamformType.h"
#include "../../beamformingCfg.h"

/********************************************
* Internal Function Declaration
********************************************/



/********************************************
* Internal Types and Variables
********************************************/
#define MEM_FULL 1
#define MEM_FREE 0
#define MEM_TRANSFERING 0xff
/********************************************
* External Variables
********************************************/
extern SEM_Obj SemHwi2DataParser;
extern SEM_Obj SemTest;
extern SEM_Obj SemDataParserCopyMem;
extern SEM_Obj LockerMemAllocTable;

#pragma DATA_SECTION(dataParserMemPing, "data_parser_mem_section");
uint16_t dataParserMemPing[CHANNEL_NO*ONE_CHANNEL_SIGNAL_BLK_SZ];
#pragma DATA_SECTION(dataParserMemPong, "data_parser_mem_section");
uint16_t dataParserMemPong[CHANNEL_NO*ONE_CHANNEL_SIGNAL_BLK_SZ];
//volatile uint16_t pingpongState[2] = {MEM_FREE,MEM_FREE};
volatile uint16_t isPingTurnForTransfer = TRUE;
/********************************************
* Functions
********************************************/
Void APP_TskDataParser(Arg id_arg ){

    MBMsg_t msg;
    uint32_t addr = 0;


    for(;;){
        //get a memory block
        addr = MemManagerMalloc();

        while(addr == 0){
            //give up the execution, and sleep sometimes
            TSK_sleep(10);
        };

        //configure the dma to transmit the adc data


        //wait for dma copy configuration registers
        //and then configure the next configuration


        // wait for HWI event (DMA transfer half ready or
        // ready event) to post a semaphore
        SEM_pend(&SemHwi2DataParser, SYS_FOREVER);

        //Send the message to inform the SignalProcessor
        msg.addr = addr;
        MBX_post(&MbDataParser2SignalProcessor, &msg, SYS_FOREVER);

    }
}




Void APP_TskDataParserPeriodic(Arg id_arg ){

    MBMsg_t msg;
    uint16_t *paddr = 0; uint32_t saddr, daddr;
    uint16_t i, channelID;
    uint32_t timestamp = 0;
    MemManagerInit();

    TSK_sleep(1000);

    //DMA configuration for memory copy
    DMA_Handle dmaMemCpy = DMA_open(DMA_CHA2, 0);
    DMA_Config dmaMemCpyCfg = {
        0x0409, //DMACSDP
        0x6000, //DMACCR
        0x0008,
        0,
        0,
        0,
        0,
        ONE_CHANNEL_SIGNAL_BLK_SZ, //16 clusters
        1,
        0,
        2*CHANNEL_NO-1,
        0,
        0
    };

    //DMA configuration for fetching ADC data
    //configure the dma here and start it
    ADCDrvInit();

    for(;;){

        timestamp++;

        //configure the next DMA transfer here
        isPingTurnForTransfer = !isPingTurnForTransfer;
        if(isPingTurnForTransfer){
            //configure dma to transfer ping

        } else {
            //Configure the dma to transfer pong
        }
        //DMA_config();


        //wait until current dma transfer is ready
        SEM_pend(&SemTest, SYS_FOREVER);

        //process the current dma transfer
        if(!isPingTurnForTransfer){
            paddr = dataParserMemPing;
        } else {
            paddr = dataParserMemPong;
        }

        //let's prentend the data is good
        for(i = 0; i < CHANNEL_NO*ONE_CHANNEL_SIGNAL_BLK_SZ; i++){
            paddr[i] = i;
        }

        //seperate the channel datas
        //we need to transfer the data from this memeory into anther memory
        for (channelID = 0; channelID < CHANNEL_NO; channelID++){
            //get a memory
            saddr = MemManagerMalloc();
            while (saddr == 0){
                TSK_sleep(100);
                saddr = MemManagerMalloc();
            }


            //configure the DMA to transfer the data from
            //dataparsemem to newly allocated memeory
            //SDRAM - SDRAM
            dmaMemCpyCfg.dmacdsal = (DMA_AdrPtr)((saddr << 1)&0xffff);
            dmaMemCpyCfg.dmacdsau = (uint16_t)((saddr >> 15)&0xffff);
            daddr = (uint32_t) paddr;
            daddr += channelID;
            dmaMemCpyCfg.dmacssal = (DMA_AdrPtr)((daddr << 1)&0xffff);
            dmaMemCpyCfg.dmacssau = (uint16_t)((daddr >> 15)&0xffff);


            DMA_config(dmaMemCpy, &dmaMemCpyCfg);
            DMA_start(dmaMemCpy);

            // wait for HWI event (DMA transfer half ready or
            // ready event) to post a semaphore
            SEM_pendBinary(&SemDataParserCopyMem, SYS_FOREVER);

            //Send the message to inform the SignalProcessor
            msg.addr = saddr;
            msg.timestamp = timestamp;
            msg.firstChannelID = channelID;
            msg.channelNum = 1;
            MBX_post(&MbDataParser2SignalProcessor, &msg, SYS_FOREVER);
        }

    }
}


void PeriodicTestFunc( Arg id_arg ){
    SEM_post(&SemTest);

}
