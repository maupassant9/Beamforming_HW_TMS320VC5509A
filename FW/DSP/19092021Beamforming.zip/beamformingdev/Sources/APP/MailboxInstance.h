/*
 * MailboxInstance.h
 * Author: Dong Xia
 * @description
 *
 * Change Records:
 *      >> (11/09/2021): Mailbox instances used between tasks
 *
 */

#ifndef SOURCES_APP_MAILBOXINSTANCE_H_
#define SOURCES_APP_MAILBOXINSTANCE_H_
/********************************************
* Include
********************************************/
#include <std.h>
#include <mbx.h>
#include <sem.h>
#include "../beamformType.h"

/********************************************
* Macro
********************************************/
//define the message size of each mailbox in word
#define MSG_SZ_MB_DATAPARSE_2_SIGPROCESSOR 4
#define MSG_SZ_MB_SIGPROCESSOR_2_SDWRITER 4


/********************************************
* Type definition
********************************************/

//External mailbox defined in dspbios configuration tool
extern MBX_Obj MbDataParser2SignalProcessor;
extern MBX_Obj MbSignalProcessor2SDWriter;

typedef struct{
    uint32_t addr;
    uint32_t timestamp;
    //firstChannel ID should be the from
    //1 .... N
    //for multiple channel, use 0
    uint16_t firstChannelID;
    //number of channel inside block
    //should be from 1 to N
    uint16_t channelNum;
}MBMsg_t;


/********************************************
* Function prototype
********************************************/



#endif /* SOURCES_APP_MAILBOXINSTANCE_H_ */
