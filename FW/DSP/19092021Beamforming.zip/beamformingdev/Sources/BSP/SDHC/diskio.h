bool_dt SdWriteSector(ulong_dt sector_addr_ul, uint_dt * data_ptr_uc);
bool_dt SdReadSector(ulong_dt sector_addr_ul,uint_dt * data_ptr_uc);
ulong_dt DataTime(void);
bool_dt SdInit();

void DiskInit();

void ReadSector(ulong_dt sector_addr_ul,uint_dt * data_ptr_uc);
void WriteSector(ulong_dt sector_addr_ul,uint_dt * data_ptr_uc);