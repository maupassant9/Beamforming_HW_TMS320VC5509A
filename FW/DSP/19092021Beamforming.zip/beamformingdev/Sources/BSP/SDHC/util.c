/*
 *  Copyright (C) 2001, Spectrum Digital, Inc.  All Rights Reserved.
 */

#include "5509.h"
#include "util.h"

DSPCLK dspclk;
//=========================================================
//函 数 名:void PLL_Init(int freq)
//功    能:DSP系统时钟设置
//入口参数:freq:12的整数倍
//出口参数:
//返 回 值:
//=========================================================
void PLL_Init(int freq)
{
    int i;
    DSPCLK dspclk;
    ioport unsigned int *clkmd;        //定义时钟模式寄存器
    ioport unsigned int *sysr;
    clkmd=(unsigned int *)0x1c00;
    sysr=(unsigned int *)0x07fd;
    
    // Calculate PLL multiplier values (only integral multiples now)
    dspclk.clkin = DSP_CLKIN;          //输入频率
    dspclk.pllmult = (freq *2)/ dspclk.clkin;   //为什么乘2　　公式中分母为div+1，div设成了 1
    
    if(dspclk.pllmult>= 32)dspclk.pllmult=31;   //相乘数范围0到31,超过的按31算
   // dspclk.nullloopclk = NULLLOOP_CLK;

    // Turn the PLL off
    *clkmd &= ~0x10; //pll enable = 0;¡¡
    for(i=*clkmd&1; i!= 0 ;i=*clkmd&1);   //等待pll进入旁路状态

    // Initialize PLL flags
    *clkmd &= ~0x4000; // iai=0;¡¡
    *clkmd |= 0x2000;  // iob=1;  
      // Set the multiplier/divisor
  //  WriteMask(pCMOD -> clkmd,
  //      CLKMD_PLLDIV_1 | CLKMD_BYPASSDIV_1,
  //      CLKMD_PLLDIV_MASK | CLKMD_BYPASSDIV_MASK);
    *clkmd &= ~0xc;//把旁路下分频数清零
    *clkmd |= 4;   //0000.0000.0000.0100   设置div为０１，即１分频
    *clkmd &= ~0x60;//把锁定模式下的分频数清零
    *clkmd |= 0x20; //设把锁定模式下的分频数为１
    //WriteField(pCMOD -> clkmd, dspclk.pllmult, CLKMD_PLLMULT_MASK);
    *clkmd &= ~0x0f80;//把锁定模式下的倍频数清零
    *clkmd |= dspclk.pllmult<<7;       //把倍频数写入该寄存器
    // Enable the PLL and wait for lock
    *clkmd|=0x10;//pll enable = £±;
    for(i=0;i<10;i++);//Ð¡ÑÓÊ±
   for(i=*clkmd&1; i!= 1 ;i=*clkmd&1);//等待pll进入锁定状态
    
    *sysr=4;     //8分频输出
}

//=========================================================
//以下是一些小函数，如全局中断等
//=========================================================
void INT_Enable(unsigned short mask)
{
    *IER0 = *IER0 | mask;
}

void INT_Disable(unsigned short mask)
{
    *IER0 = *IER0 & ~mask;
}

void INT_EnableGlobal()
{
    asm(" BCLR INTM");
}

void INT_DisableGlobal()
{
    asm(" BSET INTM");
}

void INT_SetVec(unsigned long addr)
{
    *IVPD = (unsigned short)(addr >> 8);
    *IVPH = *IVPD;
}


void INT_InstallHandler(int vecno, void(*handler)())
{
    unsigned long handler_addr, vec_addr;
    unsigned short *pdata;

    // Calculate address of vector
    vec_addr = (unsigned long)*IVPD;
    vec_addr = vec_addr << 7;
    vec_addr += vecno * 4;

    // Insert branch to handler in vector location
    handler_addr = (unsigned long)handler;
    pdata = (unsigned short *)vec_addr;
    *pdata++ = ((handler_addr >> 16) & 0x00ff) | 0xea00;
    *pdata++ = handler_addr & 0xffff;
    *pdata++ = 0x5e80;
    *pdata++ = 0x5f80;
}

void SWDelayUsec(unsigned int usec)
{
    unsigned int i, j, loopsperusec;

    loopsperusec = dspclk.freq / dspclk.nullloopclk;
    for (i=0;i<usec;i++)
        for (j = 0; j < loopsperusec; j++);
}

void SWDelayMsec(unsigned int msec)
{
    unsigned int i;
    for (i=0;i<msec;i++)
        SWDelayUsec(1000);
}
//=========================================================
//函 数 名:int firstbit(unsigned short mask)
//功    能:
//入口参数:mask
//出口参数:shiftamt
//返 回 值:mask这个数最低哪位不为零
//=========================================================
int firstbit(unsigned short mask)
{
    int shiftamt;
    unsigned short bit;

    // Find offset of first bit in mask
    bit = 1;
    for (shiftamt = 0; shiftamt < 16; shiftamt++) {
        if (bit & mask)
            break;
        bit = bit << 1;
    }

    return shiftamt;
}
