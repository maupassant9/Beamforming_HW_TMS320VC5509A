/*
* ADCSPI.c
* Author: Dong Xia
* MCBSP configured as ADC SPI slave
* Timer1 used to generate the conversion pulse
*
*
* Change Records:
*      >> (16/09/2021): Source file created
*
*/

/********************************************
* Include
********************************************/
#include <csl_timer.h>
#include "ADCDriver.h"
#include "../../beamformType.h"


/********************************************
* Internal Function Declaration
********************************************/
static void Timer0Start(double period);



/********************************************
* Internal Types and Variables
********************************************/

/********************************************
* External Variables
********************************************/


/********************************************
* Functions
********************************************/
/*------------------------------------------------
* ADCDrvInit
* Initialize the ADC module:
* Configure the MCBSP to receive ADC data
* Configure the timer0 to generate the periodic
* timer.
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (16/09/2021): Create the function
*----------------------------------------------*/
void ADCDrvInit(){
    Timer0Start(1.0e6/SAMPLING_RATE_HZ);
}

/*------------------------------------------------
* Timer1Init
* Initialize the timer1 to generate the pulse wave
*                                    |<->| Pulsewidth (us)
*            ___                      ___
*           |   |                    |   |
* ----------     --------------------     -------
*           |<------period(us)------>|
* Paras:
*  >> period : period in us
*  >> pulsewidth : pulse width in us
* Return:
*  >>
* Change Records:
*  >> (18/09/2021): Create the function
*----------------------------------------------*/
static void Timer0Start(double period){

    TIMER_Handle htimer;
    htimer = TIMER_open(TIMER_DEV0, 0);

    uint32_t periodInClk = (uint32_t)(period*IN_CLK_FREQ_MHZ);

    TIMER_Config timercfg;
    timercfg.prd = (periodInClk/16)-1;
    timercfg.tcr = 0x8e4;
    timercfg.prsc = 0x000f;

    TIMER_config(htimer, &timercfg);
    TIMER_start(htimer);
}
