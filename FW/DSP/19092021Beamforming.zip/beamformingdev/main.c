

/**
 * main.c
 */
#include <csl.h>
#include <csl_gpio5509a.h>
#include <stdio.h>
#include <bios.h>
#include <std.h>
#include <csl_emif.h>
#include "Sources/BSP/LED/led.h"
#include "Sources/BSP/FastFat/com.h"
#include <csl_dma.h>

unsigned int card_rca;
int file_num = 0;

//uint16_t databuffer[8192];
//SD

//DMA configuration for memory copy
//DMA_Handle hdma;
//DMA_Config dma_cfg = {
//    0x0409, //DMACSDP
//    0x6000, //DMACCR, source as single index
//    0x0008,
//    0,
//    0,
//    0,
//    0,
//    10,
//    1,
//    0,
//    3,
//    0,
//    0
//};

int main(void)
{

//    uint16_t val = 0;
    int16_t * souraddr, * deminaddr, * destaddr, *souraddrcoy;
    uint32_t i = 0, j;
    uint16_t datacount=0;
    uint32_t error = 0;
    uint32_t val;
    uint32_t addr;

    CSL_init();

    IRQ_enable(IRQ_EVT_DMAC0);
    IRQ_enable(IRQ_EVT_DMAC2);
    IRQ_enable(IRQ_EVT_DMAC3);
    IRQ_enable(IRQ_EVT_DMAC4);


//    for(i = 0; i < 8192; i++){
//        databuffer[i] = 0;
//    }
//    //bspSDRAMInit_Cpu192MHz_Sdram96MHz();
    //bspSDRAMInit_Cpu192MHz_Sdram192MHz();
////    //init the gpio
////    //GPIO_pinEnable(GPIO_PIN6);
//
//    souraddr =  (int *)0x300000;
//    deminaddr = (int *)0x30ffff;
//
//    for (i = 0; i < 0x40; i++){
//        souraddr = (int16_t *)((uint32_t)0x300000+i*0x10000);
//        deminaddr = (int16_t *)((uint32_t)0x30ffff+i*0x10000);
//        datacount = 0;
//        souraddrcoy = souraddr;
//        while(souraddr<deminaddr)
//        {
//            *souraddr++ = datacount;
//            datacount++ ;
//        }
//
//        souraddr =  souraddrcoy;
//        datacount = 0;
//        while(souraddr<deminaddr)
//        {
//            deminaddr[datacount++] = *souraddr++;
//            if(deminaddr[datacount-1]!=(datacount-1))
//                error++;
//        }
//        souraddr = souraddrcoy;
//
//    }
//
    bspLedInit();
    //bspSetFreq(0, 1); //frequency = 10 perodic tick = 1000s

    //////////////////////////////////////////////////
    // DMA SDRAM - SDRAM
    //////////////////////////////////////////////////
//    souraddr =  (int *)0x300000;
//    for(i = 0; i < 4096; i++){
//        *souraddr++ = i;
//    }
//    destaddr = (int *)0x400000;
//
//    hdma = DMA_open(DMA_CHA0,0);
//
//    addr = ((uint32_t)0x300000)<<1;
//    dma_cfg.dmacssal = (DMA_AdrPtr)(addr&0xffff);
//    dma_cfg.dmacssau = (uint16_t)((addr&0xffff0000)>>16);
//    addr = ((uint32_t)destaddr)<<1;
//    dma_cfg.dmacdsal = (DMA_AdrPtr)(addr&0xffff);
//    dma_cfg.dmacdsau = (uint16_t)((addr&0xffff0000)>>16);
//    dma_cfg.dmacen = 10;
//    DMA_config(hdma, &dma_cfg);
//    DMA_start(hdma);
//    //wait for dma transfer finished
//    while(!DMA_FGETH(hdma, DMACSR, FRAME));
//    DMA_close(hdma);
//
//    while(1);


}
