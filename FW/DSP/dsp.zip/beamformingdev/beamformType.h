/*
 * beamformType.h
 *
 *  Created on: 2 de mai de 2021
 *      Author: xiado
 */

#ifndef BEAMFORMTYPE_H_
#define BEAMFORMTYPE_H_

typedef unsigned char uint8_t;
typedef char int8_t;
typedef unsigned int uint16_t;
typedef int int16_t;
typedef unsigned long uint32_t;
typedef long int32_t;

#endif /* BEAMFORMTYPE_H_ */
