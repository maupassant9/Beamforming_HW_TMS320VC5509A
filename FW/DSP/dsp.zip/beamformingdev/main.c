

/**
 * main.c
 */
#include <csl.h>
#include <csl_gpio5509a.h>
#include <stdio.h>



int main(void)
{

    CSL_init();
    //init the gpio

    //GPIO_pinEnable(GPIO_PIN6);
    GPIO_pinDirection(GPIO_PIN6,GPIO_IODATA_IO6D_OUTPUT);
    GPIO_pinWrite(GPIO_PIN6,1);

    while(1);

}
