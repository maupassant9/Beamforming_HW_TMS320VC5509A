

/**
 * main.c
 */
#include <csl.h>
#include <csl_gpio5509a.h>
#include <stdio.h>
#include <bios.h>
#include <std.h>
#include <csl_emif.h>
#include "Sources/BSP/LED/led.h"



uint16_t databuffer[0x2000];


int main(void)
{

//    uint16_t val = 0;
    int16_t * souraddr, * deminaddr, * destaddr, *souraddrcoy;
    uint32_t i = 0, j;
    uint16_t datacount=0;
    uint32_t error = 0;
    uint32_t val;


    CSL_init();
    //bspSDRAMInit_Cpu192MHz_Sdram96MHz();
    bspSDRAMInit_Cpu192MHz_Sdram192MHz();
//    //init the gpio
//    //GPIO_pinEnable(GPIO_PIN6);

    souraddr =  (int *)0x300000;
    deminaddr = (int *)0x30ffff;

    for (i = 0; i < 0x40; i++){
        souraddr = (int16_t *)((uint32_t)0x300000+i*0x10000);
        deminaddr = (int16_t *)((uint32_t)0x30ffff+i*0x10000);
        datacount = 0;
        souraddrcoy = souraddr;
        while(souraddr<deminaddr)
        {
            *souraddr++ = datacount;
            datacount++ ;
        }

        souraddr =  souraddrcoy;
        datacount = 0;
        while(souraddr<deminaddr)
        {
            deminaddr[datacount++] = *souraddr++;
            if(deminaddr[datacount-1]!=(datacount-1))
                error++;
        }
        souraddr = souraddrcoy;

    }

    bspLedInit();
    bspSetFreq(0, 10); //frequency = 10 perodic tick = 1000s


}
