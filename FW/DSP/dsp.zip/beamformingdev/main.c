

/**
 * main.c
 */
#include <csl.h>
#include <csl_gpio5509a.h>
#include <stdio.h>
#include <bios.h>
#include <std.h>
#include <csl_emif.h>
#include "Sources/BSP/LED/led.h"

#define EBSR         *(ioport volatile unsigned int *)0x6C00

void memoryInit();
int databuffer[2000];

int main(void)
{

//    uint16_t val = 0;
    int * souraddr, * deminaddr;
    int datacount=0, error = 0;

    CSL_init();
    memoryInit();

//    //init the gpio
//    //GPIO_pinEnable(GPIO_PIN6);


    souraddr =  (int *)0x240000;
    deminaddr = (int *)0x240100;
    while(souraddr<deminaddr)
    {
        *souraddr++ = datacount;
        datacount++ ;
    }

    souraddr =  (int *)0x240000;
    datacount = 0;
    while(souraddr<deminaddr)
    {
        databuffer[datacount++] = *souraddr++;
        if(databuffer[datacount-1]!=(datacount-1))
            error++;
    }

    bspLedInit();
    bspSetFreq(0, 10);


}



void memoryInit(){
    EMIF_Config MyConfig = {
        0x0220, /* egcr */ //ok
        0xFFFF, /* emirst */
        0x3FFF, /* ce01 */  //ok
        0x0000, /* ce02 */  //ok
        0x0000, /* ce03 */  //ok
        0x3FFF, /* ce11 */  //ok
        0x0000, /* ce12 */  //ok
        0x0000, /* ce13 */  //ok
        0x3FFF, /* ce21 */  //ok
        0x0000, /* ce22 */  //ok
        0x0000, /* ce23 */  //ok
        0x3FFF, /* ce31 */  //ok
        0x0000, /* ce32 */  //ok
        0x0000, /* ce33 */  //ok
        /*TRC: 65ns*96M  - 1= 6.24 - 1 = 5.24
        TRCD: 20ns*96M -1 = 1.92 -1 = 0.92
        TRP: 0.92
        TMRD: 4
        TRAS:  45ns*96M - 1 = 4.32 - 1 = 3.32
        TACTV2ACTV = tRRD: 15*96 - 1 = 0.439
        */
        0x3511, /* sdc1 */  //ok  0x3411?
        0x0fff, /* sdper */  //ok??  0x0410
        0x07FF, /* init */
        0x0141 /* sdc2 */   //ok
    };

    EBSR = 0x281;
    EMIF_config(&MyConfig);
}
