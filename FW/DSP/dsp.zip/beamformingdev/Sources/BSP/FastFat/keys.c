//=====================================
//Variable and function for STORAGE ROOM
//=====================================

#define ROOM_LENGTH 16



#define ERR 0xff

//Storage room: Used for store the data.
#pragma DATA_SECTION(data_buffer1,"dmaMem")
unsigned int data_buffer1[4096]={0};
  //!!!!!!���ȱ���һ��buffer��һ����ԭ���ǣ�
  //�ڴ��ڶ�����buffer��ʱ��ഫ��һ
  //��buffer�����һ��!!!!!!!!!!!!!!!!!!!
#pragma DATA_SECTION(data_buffer2,"dmaMem")
unsigned int data_buffer2[4096]={0};

#pragma DATA_SECTION(data_buffer3,"dmaMem")
unsigned int data_buffer3[4096]={0};

#pragma DATA_SECTION(data_buffer4,"dmaMem")
unsigned int data_buffer4[4096]={0};

#pragma DATA_SECTION(data_buffer5,"dmaMem")
unsigned int data_buffer5[4096]={0};

#pragma DATA_SECTION(data_buffer6,"dmaMem")
unsigned int data_buffer6[4096]={0};

#pragma DATA_SECTION(data_buffer7,"dmaMem")
unsigned int data_buffer7[4096]={0};

#pragma DATA_SECTION(data_buffer8,"dmaMem")
unsigned int data_buffer8[4096]={0};

//=========================================
#pragma DATA_SECTION(data_buffer9,"dmaMem")
unsigned int data_buffer9[4096]={0};

#pragma DATA_SECTION(data_buffer10,"dmaMem")
unsigned int data_buffer10[4096]={0};

#pragma DATA_SECTION(data_buffer11,"dmaMem")
unsigned int data_buffer11[4096]={0};

#pragma DATA_SECTION(data_buffer12,"dmaMem")
unsigned int data_buffer12[4096]={0};

#pragma DATA_SECTION(data_buffer13,"dmaMem")
unsigned int data_buffer13[4096]={0};

#pragma DATA_SECTION(data_buffer14,"dmaMem")
unsigned int data_buffer14[4096]={0};

#pragma DATA_SECTION(data_buffer15,"dmaMem")
unsigned int data_buffer15[4096]={0};

#pragma DATA_SECTION(data_buffer16,"dmaMem")
unsigned int data_buffer16[4096]={0};



#pragma DATA_SECTION(trash,"dataMem")
unsigned int trash[1]={0};


//when DMA finish his job, he will sign on this paper
//and when SD comes here, he will check the paper and
//move according to this paper
extern unsigned int task_table[ROOM_LENGTH] = {0xff,
                                               0xff,
											   0xff,
											   0xff,
											   0xff,
											   0xff,
											   0xff,
											   0xff,
											   0xff,
                                               0xff,
											   0xff,
											   0xff,
											   0xff,
											   0xff,
											   0xff,
											   0xff};
                                                 



extern int current_key_dma = 0xff;
extern int current_key_sd = 0;


/*
//Scheduling the storage room
void ApplyEmptyStorage(void)
{
    
    asm(" NOP");

}


//Scheduling the storage room
int ApplyTask(void)
{
    int temp;
    
    temp = task_table[current_key_sd];


    //�ж���������Ƿ�������
    if (temp == 0xff)
	{
	    return ERR;
	}
	else //�������򷵻�������
	{
	    return temp;
	}
}

*/
//Open an storage room using the key
//It will give the pointer of the 
//storage room for applications to use

unsigned int * OpenStorageRoom(int key_num)
{
    
    unsigned int * data_ptr;

    
    //Get the storage room label
	switch(key_num)
	{
	    case 0:  data_ptr = data_buffer1;
	             break;
		case 1:  data_ptr = data_buffer2;
	             break;
	    case 2:  data_ptr = data_buffer3;
	             break;		      
		case 3:  data_ptr = data_buffer4;
	             break;
	    case 4:  data_ptr = data_buffer5;
	             break;
		case 5:  data_ptr = data_buffer6;
	             break;
		case 6:  data_ptr = data_buffer7;
	             break;
		case 7:  data_ptr = data_buffer8;
	             break;
        //==============================
		case 8:  data_ptr = data_buffer9;
	             break;
		case 9:  data_ptr = data_buffer10;
	             break;
		case 10:  data_ptr = data_buffer11;
	             break;
		case 11:  data_ptr = data_buffer12;
	             break;
		case 12:  data_ptr = data_buffer13;
	             break;
		case 13:  data_ptr = data_buffer14;
	             break;
		case 14:  data_ptr = data_buffer15;
	             break;
		case 15:  data_ptr = data_buffer16;
	             break;

		default: data_ptr = trash;break;
	}

    return data_ptr;
		
}

/*
//Telling the scheudling system that 
//he finished the job, and he will 
//return the key and lock the room
void DmaReturnKey(key_num)
{
    //��task_table���еǼ�
    task_table[current_key_dma] = 0x01;

	current_key_dma++;
    
    if (current_key_dma == ROOM_LENGTH)
	{
	    current_key_dma = 0;
	}
	
}

//Telling the scheudling system that 
//he finished the job, and he will 
//return the key and lock the room
void SdReturnKey(key_num)
{
    
    //��task_table�н��еǼ�,����ɸ�����
	//����ָ����һ������
	task_table[current_key_sd] = 0xff;

	current_key_sd++;

    if (current_key_sd == ROOM_LENGTH)
    {
	    current_key_sd = 0;
	}

}

*/



