/*
 *File name: init.c
 *--------------------------
 * Author: Xiadong
 * Create time: 9-Apr-2009
 * Email:  xiadong.cn@gmail.com
 *---------------------------
  * 使用注意事项：
 * 目录项所占簇对应FAT表项不能超过一个扇区的边界
 * 必须手动指定文件系统bpb信息
 * 要求手动分配足够的簇给目录项，且必须从第二簇开始
 * 不检查坏区。
 * 不能任意增加文件长度，要求每次增加长度以簇为单位
 * 建立文件的个数没有256的限制，但不能超过2559个文件
 * 不支持文件夹，不支持文件删除，磁盘格式化，不支持长文件名
 *--------------------------------*/

 #include "fat.h"
 #include "../SDHC/diskio.h"
 #include <csl_i2c.h>
 //===========================================
 // This file is a part of SimpFat project,  //
 // Used to Init SimpleFat.                  //
 // The main function here is FatInit();     //
 //                                          //
 //        FatInit----link the diskio        //
 //               with disk_handler. Apply   //
 //               space for fat file system  //
 //==========================================//
		
//目录项信息
//用来存储分配给目录项簇地址的空间,2~11簇已分给目录项
ulong_dt fdt_list[FDT_NUM] = {2,3,4,5,6,7,8,9,10,11};
uint_dt current_fdt_content[16] = {0}; //当前文件目录项信息
ulong_dt fdt_cnt = 0;//记录当前fdt相对位置
ulong_dt file_info[2] = {0};//分别记录当前文件最后一簇和文件长度信息(以簇为单位)
//记录已分配空间的FAT表的的位置信息
ulong_dt fat_cnt = 0; //已分配的簇；
unsigned int time_stamp[2];//时间戳
extern file_num;
 
//由簇地址得到扇区地址
#define ClusterAddr2SectorAddr(N)  (N-2)*SEC_PER_CLU + FIRST_DATA_SEC
//由簇地址得到对应FAT表项的扇区地址
#define ClusterAddr2FatSector(N) RSVD_SEC + HIDDEN_CLUSTER + (N<<2)/BYTS_PER_SEC
//由簇地址得到对应FAT表项的偏移量
#define ClusterAddr2FatOffset(N) (N<<2)%BYTS_PER_SEC
#define FAT_HEAD (RSVD_SEC + HIDDEN_CLUSTER)
#define FAT_END (RSVD_SEC + HIDDEN_CLUSTER+ FAT_SZ)

 uint_dt buffer_temp[BUFFER_SIZE];
 void GetTime(void);
void  GetDiskImformation(void);
//初始化磁盘文件系统
//获得磁盘的文件系统信息
//计算一些基本信息
//--------OK--------------
void FatInit()
{
    uint_dt cnt;
    ulong_dt temp_ul;
    uint_dt offset; //fat表的偏移
    //初始化磁盘
    DiskInit(); 
    //搜索磁盘信息
    GetDiskImformation();

    //如果是一张格式化的卡，则目录项在第２簇
    if(fat_cnt == fdt_list[0])
	{
        //清空目录项
		fdt_cnt = 0;
		fat_cnt = fdt_list[FDT_NUM-1] ;//FDT的下一簇

	    for(cnt = 1; cnt < FDT_NUM; cnt++)//从1开始，因为最开始的一簇格式化时已初始化
	    {
	         FlushCluster(fdt_list[cnt]);
	    }
	}

    //可以在此先为目录项建立FAT
	temp_ul = ClusterAddr2FatSector(fdt_list[0]); //确定Fdt所对应fat表的扇区数
	offset = ClusterAddr2FatOffset(fdt_list[0])/2; //偏移量(以byte为单位)
    //修改对应的fat表项
    //将该扇区内容读出
	ReadSector(temp_ul,buffer_temp);

	for(cnt = 1; cnt < FDT_NUM; cnt++)
	{
		buffer_temp[offset++] = (uint_dt)(((ltb_end32(fdt_list[cnt])) & 0xffff0000)>>16);
		buffer_temp[offset++] = (uint_dt)((ltb_end32(fdt_list[cnt])) & 0x0000ffff);
	}
	//最后一个标记为0x0fffffff
	buffer_temp[offset++] = 0xffff;
	buffer_temp[offset++] = 0xff0f;
	WriteSector(temp_ul,buffer_temp);
}



//修改日期：12-apr-09
//代码来源自DOSFS，作者为Lewin Edwards,做了部分修改。
//---------------OK--------------------
/*
	DOSFS Embedded FAT-Compatible Filesystem
	(C) 2005 Lewin A.R.W. Edwards (sysadm@zws.com)

	You are permitted to modify and/or use this code in your own projects without
	payment of royalty, regardless of the license(s) you choose for those projects.

	You cannot re-copyright or restrict use of the code as released by Lewin Edwards.

	Convert a filename element from canonical (8.3) to directory entry (11) form
	src must point to the first non-separator character.
	dest must point to a 12-byte buffer.
*/
void CanonicalToDir(uchar_dt *dest, uchar_dt *src)
{
	uchar_dt *destptr = dest;
	uchar_dt temp_cnt_uc = 0;



	for(temp_cnt_uc = 0; temp_cnt_uc < 11; temp_cnt_uc++)
       	{
		if (*src >= 'a' && *src <='z') {
			*destptr++ = (*src - 'a') + 'A';
			src++;
		}
		else if (*src == '.') {
			src++;
			while(destptr-dest <= 7)
			{
				*destptr++ = 0x20;
			}
			//一定要等于8，防止内存泄露！！！
			temp_cnt_uc = 7;

		}
		else {
			*destptr++ = *src++;
		}
	}
	dest[0] = (dest[0]<<8)+dest[1];
	dest[1] = (dest[2]<<8)+dest[3];
	dest[2] = (dest[4]<<8)+dest[5];
	dest[3] = (dest[6]<<8)+dest[7];
	dest[4] = (dest[8]<<8)+dest[9];
	dest[5] = (dest[10]<<8);	

}



//在FAT表中为文件申请簇空间
// 19-Apr-09
//--------OK------------
bool_dt  ApplyFreeSector(uint_dt file_first_cluster)
{
	ulong_dt temp1_ul,temp2_ul;

	//分配下一簇
	fat_cnt++;
	//如果是该簇则重新分配
	if (fat_cnt == 0xffffff7)
	{
	     fat_cnt++;
	}
	//判断有没有超出边界
	if(fat_cnt > TOTAL_CLU)
	{
		Err();
		return ISFALSE;
	}
	else //没有超出界，则修改fat表项
	{
		temp1_ul = ClusterAddr2FatSector(fat_cnt);

		//如果本簇与上一簇在同一扇区则：
		if(fat_cnt % ((ulong_dt)FAT_CONTENT_PER_SEC) != 0)
		{
			ReadSector(temp1_ul,buffer_temp);
			//修改当前簇对应的值
			temp2_ul = ClusterAddr2FatOffset(fat_cnt)/2;
			buffer_temp[temp2_ul] = 0xffff;
			buffer_temp[temp2_ul+1] = 0xff0f;
			//不是文件第一个簇则修改前一簇
			if(!file_first_cluster)
			{
			    //修改前一簇对应的值
				buffer_temp[temp2_ul-2] = (uint_dt)(((ltb_end32(fat_cnt)) & 0xffff0000)>>16);
				buffer_temp[temp2_ul-1] = (uint_dt)((ltb_end32(fat_cnt)) & 0x0000ffff);
			}
			WriteSector(temp1_ul,buffer_temp);
		}
		else
		{
		    //不再同一扇区则：
			ReadSector(temp1_ul,buffer_temp);
			buffer_temp[0] = 0xffff;
			buffer_temp[1] = 0xff0f;
			WriteSector(temp1_ul,buffer_temp);
			//再读上一扇区
			if(!file_first_cluster)
			{
			    //修改前一簇对应的值
				ReadSector(temp1_ul-1,buffer_temp);
				buffer_temp[254] = (uint_dt)(((ltb_end32(fat_cnt)) & 0xffff0000)>>16);
				buffer_temp[255] = (uint_dt)((ltb_end32(fat_cnt)) & 0x0000ffff);
				WriteSector(temp1_ul-1,buffer_temp);
			}
			
		}
	}
	return ISTRUE; //成功返回
}
	

//添加fdt表项的内容
//19-APR-09
//----------OK---------
bool_dt AddFdtContent(uint_dt * current_fdt_content)//磁盘句柄
{
        uint_dt cluster_num = 0;
		uint_dt sector_offset= 0;
		uint_dt byts_offset = 0;
		uint_dt cnt = 0;

		ulong_dt temp1_ul, temp2_ul;

		//指向下一项
		fdt_cnt += 32;

		cluster_num = (uint_dt)(fdt_cnt / BYTS_PER_CLU); //FDT所占簇的个数 - 1
		sector_offset = (fdt_cnt - cluster_num * BYTS_PER_CLU) / BYTS_PER_SEC;
		byts_offset = fdt_cnt % BYTS_PER_SEC;
		//如果超出fdt的范围，则返回错误
		if(cluster_num > FDT_NUM) return ISFALSE;
		//根据位置信息修改目录项
        //读出当前所在目录项的扇区
		ReadSector(ClusterAddr2SectorAddr(fdt_list[cluster_num])+sector_offset,buffer_temp);
		//修改值，并写入
		for(cnt = 0; cnt < 16; cnt++) buffer_temp[byts_offset/2+cnt] = *current_fdt_content++;
		WriteSector(ClusterAddr2SectorAddr(fdt_list[cluster_num])+sector_offset,buffer_temp);
		
		return ISTRUE;
}



//修改fdt表项的内容
//19-APR-09
//----------OK---------
void ModifyFdtContent(uint_dt * current_fdt_content)
{
	    uint_dt cluster_num = 0;
		uint_dt sector_offset= 0;
		uint_dt byts_offset = 0;
		uint_dt cnt = 0;
	
		cluster_num = fdt_cnt / BYTS_PER_CLU;
		sector_offset = (fdt_cnt - cluster_num * BYTS_PER_CLU) / BYTS_PER_SEC;
		byts_offset = fdt_cnt % BYTS_PER_SEC;
		
		//根据位置信息修改目录项
        //读出当前所在目录项的扇区
		ReadSector(ClusterAddr2SectorAddr(fdt_list[cluster_num])+sector_offset,buffer_temp);
		//修改值，并写入
		for(cnt = 0; cnt < 16; cnt++) buffer_temp[byts_offset/2+cnt] = *current_fdt_content++;
		WriteSector(ClusterAddr2SectorAddr(fdt_list[cluster_num])+sector_offset,buffer_temp);
}



//============================================NEXT¡¡FILE===================================================

//创建文件
//19-Apr-09
bool_dt CreateFile(uchar_dt * file_name_ucp)//文件名
{
	uint_dt cnt_ui = 0;
	uchar_dt name_p[12];


	//初始化current_fdt_content变量
	CanonicalToDir(name_p,file_name_ucp); //转换文件名信息

	for(cnt_ui = 0;cnt_ui < 5;cnt_ui++)
	{
		current_fdt_content[cnt_ui] = name_p[cnt_ui];
	}
	current_fdt_content[5] = name_p[5]+0x20;  //标记为文件
	current_fdt_content[6] = 0;

	GetTime();
	//文件创建时间
	current_fdt_content[7] = time_stamp[1];;
	current_fdt_content[8] = time_stamp[0];;
	
	//修改文件最后写的时间和文件长度。
	current_fdt_content[11] = time_stamp[1];
	current_fdt_content[12] = time_stamp[0];
    //该文件目录项对应簇号
    //由于是新创建的文件，所以簇号为0,表示未分配
	current_fdt_content[13] = 0;
	current_fdt_content[10] = 0;
	//ÎÄ¼þ´óÐ¡
	current_fdt_content[14] = 0; //未添加内容，文件大小为0
	current_fdt_content[15] = 0; //未添加内容，文件大小为0

	//标记为新文件
	file_info[0] = 0x00; // 文件最后簇，当前文件是否是新建文件
	file_info[1] = 0x00; // 文件长度


	//增加目录项
	return AddFdtContent(current_fdt_content);
}



//为文件添加内容
//21-Apr-09
bool_dt AppendFile(uint_dt * append_content)
{
	ulong_dt cnt = 0;
	bool_dt temp_bl;

	if(file_info[0] == 0) //该文件为新建文件，没有为它分配空间
	{
		temp_bl = ApplyFreeSector(1);
		//修改目录项，添加起始簇
		current_fdt_content[13] = ltb_end16((uint_dt)(fat_cnt));//保存低位
		current_fdt_content[10] = ltb_end16((uint_dt)(fat_cnt>>16)); //保存高

	}
	else
	{
		temp_bl = ApplyFreeSector(0);
	}
	//是否申请成功
	if(temp_bl == ISFALSE)
	{
		return ISFALSE;
	}
	//将分配到的簇地址记录下来
	file_info[0] = fat_cnt;
	
	//填充一簇的数据
	WriteCluster(fat_cnt,append_content);

	//修改文件长度,增加一个簇的长度
	file_info[1] += BYTS_PER_CLU;
	//修改文件最后写的时间和文件长度。
	//current_fdt_content[11] = 0x1076;
	//current_fdt_content[12] = 0x893a;
	//文件大小
	current_fdt_content[15] =ltb_end16((uint_dt)(file_info[1]>>16));
	current_fdt_content[14] = ltb_end16((uint_dt)(file_info[1]));

	ModifyFdtContent(current_fdt_content);
	return ISTRUE;
}


//清空一簇
void FlushCluster(ulong_dt cluster_addr)
{
    uint_dt data_ptr[BYTS_PER_CLU/2];
	uint_dt cnt_ui = 0;

	//申请一定大小的空间,并且已初始化
	for(cnt_ui = 0; cnt_ui < BYTS_PER_CLU/2; cnt_ui++) data_ptr[cnt_ui] = 0;

        WriteCluster(cluster_addr,data_ptr);
}


void Err()
{
    while(1);
}

void  GetDiskImformation(void)
{
    unsigned long temp,temp2;
	int not_found = 1;
	int counter = 0;
	unsigned int i = 0;
	//获取磁盘fat_cnt，fdt_cnt

	for(i = 0; i < 0xffff; i++);
	
	//1.查找fat_cnt信息,搜索fat表
    temp = FAT_HEAD;
    	
    while (temp < FAT_END)
	{
	  	ReadSector(temp,buffer_temp);
	  	//搜索该扇区直到值为0x0000的簇
		temp2 = 0;
		while(temp2 < BYTS_PER_SEC/2)
		{
		    if (buffer_temp[temp2] == 0x0)
			{
			    if(buffer_temp[temp2+1] == 0)
				{
				    not_found = 0;break;
				}
			}

		    //指向下一个fat项
			temp2 += 2;
		}
		

		//如果已找到，则跳出循环
		if(not_found == 0)
		{
		    //获得fat_cnt 信息
		    fat_cnt = (temp - FAT_HEAD)*FAT_CONTENT_PER_SEC;
		    fat_cnt += ((temp2 >> 1) - 1);
			break;
		}

		//指向下一扇区
		temp++;


	}
    //2.查找fdt信息，搜索文件
    //fdt对应的首扇区
    temp = ClusterAddr2SectorAddr(fdt_list[0]);
    //fdt 结束扇区
  	temp2 = FDT_NUM * SEC_PER_CLU + temp;

	not_found = 1;

	while(temp < temp2)
	{
	    //查找ｆｄｔ所对应的扇区
	  	ReadSector(temp,buffer_temp);

		while(1)
		{
		    int temp3;

			temp3 = buffer_temp[counter/2];
			temp3 &= 0xff00;


			//若为0或者0xE5则找到并跳出循环
		    if(temp3 == 0) 
		    {
		        not_found = 0;
		        break;
			}

			if(counter == 512)
			{
			    counter = 0;
				break;
			}
			//指到下一个fdt项的开头
     		counter += 32;
		}
		
		//找到则结束搜索
		if(not_found == 0) break;
		
		//指到下一个扇区
		temp++;
	}

	//计算得到fdt_cnt数据
	fdt_cnt = (temp-FIRST_DATA_SEC) * BYTS_PER_SEC + counter - 32;

	file_num = fdt_cnt/32;

}





void GetTime(void)
{
    //保存时间信息hh-mm-ss
    Uint16 time_info[7];
    //获取的DS3231寄存器地址
    Uint16 reg_addr = 0x00;
    //临时变量
	int temp1,temp2;



    //Tell DS3231 to the register address
    /* Write a data byte to I2C */
	while(!I2C_xrdy());
	temp1 = I2C_write(&reg_addr,//command to send
	                 1,//length
	                 1,//master/salve
                  0x68,//Slave address
				     1,//Transfer Mode.
					 30000);//Time out
    //Obtain current time information
	temp2 = I2C_read(time_info,
	                  7,//length
					  1,//Master/Slave
				   0x68,
					  1,//Transfer Mode
					  30000,//Time out
					  1);//Check bus flag

   //Convert the date and time information
   //YEAR:time_info[6]
   temp1 = ((time_info[6]&0xf0)>>4)*10;
   time_info[6] = (time_info[6]&0x0f) + temp1 + 20;
   //Month:time_info[5]
   temp1 = ((time_info[5]&0xf0)>>4)*10;
   time_info[5] = (time_info[5]&0x0f) + temp1;
   //DATA:time_info[4]
   temp1 = ((time_info[4]&0xf0)>>4)*10;
   time_info[4] = (time_info[4]&0x0f) + temp1;
   //Hour:time_info[2]
   temp1 = ((time_info[2]&0xf0)>>4)*10;
   time_info[2] = (time_info[2]&0x0f) + temp1;
   //Minute:time_info[1]
   temp1 = ((time_info[1]&0xf0)>>4)*10;
   time_info[1] = (time_info[1]&0x0f) + temp1;
   //Sec:time_info[0]
   temp1 = ((time_info[0]&0xf0)>>4)*10;
   time_info[0] = (time_info[0]&0x0f) + temp1;
   time_info[0] = time_info[0] >> 1;
   
   //stamp:Date
   time_stamp[0] = time_info[6] << 9;
   time_stamp[0] += time_info[5] << 5;
   time_stamp[0] += time_info[4];
   //little endia to big endia
   time_stamp[0] = ltb_end16(time_stamp[0]);
   
   //stamp:Time
   time_stamp[1] = time_info[2] << 11;
   time_stamp[1] += time_info[1] << 5;
   time_stamp[1] += time_info[0];
   time_stamp[1] = ltb_end16(time_stamp[1]);

}
