/*
 *File name: com.h
 *--------------------------
 * Author: Xiadong
 * Create time: 11-Apr-2009
 * Email:  xiadong.cn@gmail.com
 *---------------------------*/
 
 //===========================================
 // This file is a part of SimpFat project,  //
 // 定义了一些常用的数据类型，使与设备无关
 //==========================================//
 
 #define uchar_dt unsigned char
 #define schar_dt signed char
 
 #define uint_dt unsigned int
 #define sint_dt signed int
 
 #define ulong_dt unsigned long
 #define slong_dt signed_long
 
 //定义布尔类型
 #ifndef bool_dt
typedef enum {ISTRUE,ISFALSE} bool_dt;
 #endif
 
 #define BIG_ENDIAN
 
 // 大端 小端转换 代码来源： efsl
#ifdef BIG_ENDIAN

#define ltb_end16(x)  ((((uint_dt)(x) & 0xff00) >> 8) | \
                      (((uint_dt)(x) & 0x00ff) << 8))
#define ltb_end32(x)  ((((ulong_dt)(x) & 0xff000000) >> 24) | \
                       (((ulong_dt)(x) & 0x00ff0000) >> 8)  | \
                       (((ulong_dt)(x) & 0x0000ff00) << 8)  | \
                       (((ulong_dt)(x) & 0x000000ff) << 24))

#else

#define ltb_end16(x)  (x)
#define ltb_end32(x)  (x)

#endif
