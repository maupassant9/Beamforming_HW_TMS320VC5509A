/*
* led.h
* Author: Dong Xia
* Led abrastration structure.
*
* Change Records:
*      >> (02/05/2021): created
*
*/

#ifndef SOURCES_BSP_LED_LED_H_
#define SOURCES_BSP_LED_LED_H_
/********************************************
* Include
********************************************/
#include "../beamformType.h"

/********************************************
* Macro
********************************************/
//number of LEDs
#define LED_NUM 1
//#define
//#define
//#define

/********************************************
* Type definition
********************************************/
// LED mode:
// * user controlled mode: set on or off by user
// * blink mode: user set frequency and some period service
//               should set on and off led accordingly.
enum ledMode_t {
    LED_MODE_USER_DEFINED = 0,
    LED_MODE_BLINK
};

enum ledState_t{
    LED_ON = 0,
    LED_OFF
};

//LED structures
typedef struct {
    enum ledState_t state;
    volatile enum ledMode_t mode;
    volatile uint32_t freq_in_tick;
}led_t;



/********************************************
* Function prototype
********************************************/
void bspLedWrite(uint32_t ledID, enum ledState_t state);



#endif /* SOURCES_BSP_LED_LED_H_ */
