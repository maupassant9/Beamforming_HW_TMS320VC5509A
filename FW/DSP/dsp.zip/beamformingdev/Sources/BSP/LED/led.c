/*
* led.c
* Author: Dong Xia
* Led abrastration structure.
*
* Change Records:
*      >> (02/05/2021): created
*
*/

/********************************************
* Include
********************************************/
#include <stdbool.h>
#include "led.h"


/********************************************
* Internal Function Declaration
********************************************/
static void hwLedGpioInit(void);
static void hwLedWrite(uint32_t ledID, enum ledState_t state);

static void bspLedUpdate(uint32_t ledID);
/********************************************
* Internal Types and Variables
********************************************/
typedef struct {
    //led structure
    led_t led;
    //count used for LED_BLINK mode
    uint32_t cnter;
}led_internal_t;

static led_internal_t ledArray[LED_NUM];

/********************************************
* External Variables
********************************************/


/********************************************
* Functions
********************************************/
/*------------------------------------------------
* bspLedInit
* LED init function:
* Init the led structures
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Created
*----------------------------------------------*/
void bspLedInit( void ){
    uint32_t i;

    hwLedGpioInit();

    //init all the led into the init state:
    for(i = 0; i < LED_NUM; i++){
        ledArray[i].led.state = LED_OFF;
        ledArray[i].led.mode = LED_MODE_USER_DEFINED;
        ledArray[i].led.freq_in_tick = 0;

        //set the led accordingly
        hwLedWrite(i, LED_OFF);
    }

}


void bspLedToggle(uint8_t ledId){
    led_internal_t ledInt = ledArray[ledId];
    if(ledInt.led.state == LED_ON){
        bspLedWrite(ledId, LED_OFF);
    } else {
        bspLedWrite(ledId, LED_ON);
    }
}

/*------------------------------------------------
* bspLedWrite
* Turn on or off the led
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
void bspLedWrite(uint32_t ledID, enum ledState_t state){

    hwLedWrite(ledID, state);
    ledArray[ledID].led.state = state;
}

/*------------------------------------------------
* bspLedUpdateAll();
* This function should always called to update the
* state of the leds when a tick is rsvd
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
void bspLedUpdateAll(){
    uint32_t i;

    for(i = 0; i < LED_NUM; i++){
        bspLedUpdate(i);
    }
}
/*------------------------------------------------
* bspLedUpdate();
* Update just one led, used only in periodic mode
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
static void bspLedUpdate(uint32_t ledID){
    led_internal_t ledInt = ledArray[ledID];

    if(ledInt.led.mode == LED_MODE_BLINK){
        if(ledInt.led.freq_in_tick > 0){
            if(ledInt.cnter != 0){
               ledInt.cnter--;
            }
        }
    }

    //update the gpio
    if(ledInt.cnter == 0){
        bspLedToggle(ledID);
        ledInt.cnter = ledInt.led.freq_in_tick;
    }
}


/*------------------------------------------------
* bspExitBlinkMode
* Exit the blink mode
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
void bspExitBlinkMode(uint32_t ledID){

    ledArray[ledID].led.mode = LED_MODE_USER_DEFINED;
}


/*------------------------------------------------
* bspSetFreq();
* Set the frequency of the led, and this function
* also set the mode to blink mode
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
void bspSetFreq(uint32_t ledID, uint32_t freq_in_tick){
    led_internal_t ledInt = ledArray[ledID];

    ledInt.led.freq_in_tick = freq_in_tick;
    ledInt.led.mode = LED_MODE_BLINK;
}



/*------------------------------------------------
* hwLedGpioInit
* Hardware layer LED GPIO init
* The function should configure the gpio used
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
static void hwLedGpioInit(void){

}

/*------------------------------------------------
* hwLedWrite
* Hardware layer Set the Led on or off
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
static void hwLedWrite(
        uint32_t ledID,
        enum ledState_t state){

}
