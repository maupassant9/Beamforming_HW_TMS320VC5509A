/*
* led.c
* Author: Dong Xia
* Led abrastration structure.
*
* Change Records:
*      >> (02/05/2021): created
*
*/

/********************************************
* Include
********************************************/
#include <stdbool.h>
#include <csl_gpio.h>
#include "led.h"



/********************************************
* Internal Function Declaration
********************************************/
static void hwLedGpioInit(void);
static void hwLedWrite(uint32_t ledID, enum ledState_t state);
static void bspLedUpdate(uint32_t ledID);
/********************************************
* Internal Types and Variables
********************************************/
//LED structures
typedef struct {
    enum ledState_t state;
    volatile enum ledMode_t mode;
    volatile uint32_t freq_in_tick;
    //count used for LED_BLINK mode
    uint32_t cnter;
}led_t;


static led_t ledArray[LED_NUM];

/********************************************
* External Variables
********************************************/


/********************************************
* Functions
********************************************/
/*------------------------------------------------
* bspLedInit
* LED init function:
* Init the led structures
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Created
*----------------------------------------------*/
void bspLedInit( void ){
    uint32_t i;

    hwLedGpioInit();

    //init all the led into the init state:
    for(i = 0; i < LED_NUM; i++){
        ledArray[i].state = LED_OFF;
        ledArray[i].mode = LED_MODE_USER_DEFINED;
        ledArray[i].freq_in_tick = 0;

        //set the led accordingly
        hwLedWrite(i, LED_OFF);
    }

}


/*------------------------------------------------
* bspLedToggle
* Toggle the LED
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (03/05/2021): Created
*----------------------------------------------*/
void bspLedToggle(uint8_t ledId){
    if(ledArray[ledId].state == LED_ON){
        bspLedWrite(ledId, LED_OFF);
    } else {
        bspLedWrite(ledId, LED_ON);
    }
}

/*------------------------------------------------
* bspLedWrite
* Turn on or off the led
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
void bspLedWrite(uint32_t ledID, enum ledState_t state){

    hwLedWrite(ledID, state);
    ledArray[ledID].state = state;
}

/*------------------------------------------------
* bspLedUpdateAll();
* This function should always called to update the
* state of the leds when a tick is rsvd
* This function should only be called inside a periodic
* time tick! DO NOT USE IT in other mode!!!!
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
void bspLedUpdateAll(){
    uint32_t i;

    for(i = 0; i < LED_NUM; i++){
        bspLedUpdate(i);
    }
}
/*------------------------------------------------
* bspLedUpdate();
* Update just one led, used only in periodic mode
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
static void bspLedUpdate(uint32_t ledID){
    led_t * led = &ledArray[ledID];

    if(led->mode == LED_MODE_BLINK){
        if(led->freq_in_tick > 0){
            if(led->cnter != 0){
               led->cnter--;
            }
        }
    }

    //update the gpio
    if(led->cnter == 0){
        bspLedToggle(ledID);
        led->cnter = led->freq_in_tick;
    }
}


/*------------------------------------------------
* bspExitBlinkMode
* Exit the blink mode
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
void bspExitBlinkMode(uint32_t ledID){

    ledArray[ledID].mode = LED_MODE_USER_DEFINED;
}


/*------------------------------------------------
* bspSetFreq();
* Set the frequency of the led, and this function
* also set the mode to blink mode
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
void bspSetFreq(uint32_t ledID, uint32_t freq_in_tick){
    led_t * led = &ledArray[ledID];

    led->freq_in_tick = freq_in_tick;
    led->mode = LED_MODE_BLINK;
    led->cnter = freq_in_tick;
}



/*------------------------------------------------
* hwLedGpioInit
* Hardware layer LED GPIO init
* The function should configure the gpio used to
* output mode
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
static void hwLedGpioInit(void){
    GPIO_pinDirection(GPIO_PIN6,GPIO_IODATA_IO6D_OUTPUT);
}

/*------------------------------------------------
* hwLedWrite
* Hardware layer Set the Led on or off
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (02/05/2021): Create the function
*----------------------------------------------*/
static void hwLedWrite(
        uint32_t ledID,
        enum ledState_t state){
    uint8_t val = (state==LED_ON)?1:0;
    GPIO_pinWrite(GPIO_PIN6,val);
}
