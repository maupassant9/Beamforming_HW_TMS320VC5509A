/*
* SDRAM.c:
* Author: Dong Xia
* Includes some pre-defined configurations for
* SDRAM initialziation
*
* Change Records:
*      >> (05/05/2021):created
*
*/

/********************************************
* Include
********************************************/
#include <std.h>
#include <csl.h>
#include <csl_emif.h>
#include "SDRAM.h"


/********************************************
* Internal Types and Variables
********************************************/
#define EBSR         *(ioport volatile unsigned int *)0x6C00


/********************************************
* Internal Function Declaration
********************************************/


/********************************************
* External Variables
********************************************/


/********************************************
* Functions
********************************************/
/*------------------------------------------------
* bspSDRAMInit_Cpu192MHz_Sdram96MHz
* Initialize the SDRAM with:
* CPU clock 192MHz
* SDRAM CLK 96MHz
* THIS FUNCTION DO NOT CHECK THE CPU CLK FREQ!!!
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (05/05/2021): Create the function
*----------------------------------------------*/
void bspSDRAMInit_Cpu192MHz_Sdram96MHz(){

    EMIF_Config MyConfig = {
        0x0220, /* egcr */ //ok
        0xFFFF, /* emirst */
        0x3FFF, /* ce01 */  //ok
        0x0000, /* ce02 */  //ok
        0x0000, /* ce03 */  //ok
        0x3FFF, /* ce11 */  //ok
        0x0000, /* ce12 */  //ok
        0x0000, /* ce13 */  //ok
        0x3FFF, /* ce21 */  //ok
        0x0000, /* ce22 */  //ok
        0x0000, /* ce23 */  //ok
        0x3FFF, /* ce31 */  //ok
        0x0000, /* ce32 */  //ok
        0x0000, /* ce33 */  //ok
        /*TRC: 65ns*96M  - 1= 6.24 - 1 = 5.24
        TRCD: 20ns*96M -1 = 1.92 -1 = 0.92
        TRP: 0.92
        TMRD: 4
        TRAS:  45ns*96M - 1 = 4.32 - 1 = 3.32
        TACTV2ACTV = tRRD: 15*96 - 1 = 0.439
        */
        0x3511, /* sdc1 */  //ok  0x3411?  //OK: 3511
        0x0500, /* sdper */  //ok??  0x500
        0x07FF, /* init */
        0x0141 /* sdc2 */   //ok
    };

    EBSR = 0x281;

    EMIF_config(&MyConfig);
}


/*------------------------------------------------
* bspSDRAMInit_Cpu200MHz_Sdram100MHz
* Initialize the SDRAM with:
* CPU clock 200 MHz
* SDRAM CLK 100 MHz
* THIS FUNCTION DO NOT CHECK THE CPU CLK FREQ!!!
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (05/05/2021): Create the function
*----------------------------------------------*/
void bspSDRAMInit_Cpu200MHz_Sdram100MHz(){

    EMIF_Config MyConfig = {
        0x0220, /* egcr */ //ok
        0xFFFF, /* emirst */
        0x3FFF, /* ce01 */  //ok
        0x0000, /* ce02 */  //ok
        0x0000, /* ce03 */  //ok
        0x3FFF, /* ce11 */  //ok
        0x0000, /* ce12 */  //ok
        0x0000, /* ce13 */  //ok
        0x3FFF, /* ce21 */  //ok
        0x0000, /* ce22 */  //ok
        0x0000, /* ce23 */  //ok
        0x3FFF, /* ce31 */  //ok
        0x0000, /* ce32 */  //ok
        0x0000, /* ce33 */  //ok
        /*TRC: 65ns*96M  - 1= 6.24 - 1 = 5.24
        TRCD: 20ns*96M -1 = 1.92 -1 = 0.92
        TRP: 0.92
        TMRD: 4
        TRAS:  45ns*96M - 1 = 4.32 - 1 = 3.32
        TACTV2ACTV = tRRD: 15*96 - 1 = 0.439
        */
        0x3511, /* sdc1 */  //ok  0x3411?
        0x0fff, /* sdper */  //ok??  0x0410
        0x07FF, /* init */
        0x0141 /* sdc2 */   //ok
    };

    EBSR = 0x281;

    EMIF_config(&MyConfig);
}



/*------------------------------------------------
* bspSDRAMInit_Cpu192MHz_Sdram192MHz
* Initialize the SDRAM with:
* CPU clock 192/132 MHz
* SDRAM CLK 192/132 MHz
* THIS FUNCTION DO NOT CHECK THE CPU CLK FREQ!!!
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (05/05/2021): Create the function
*----------------------------------------------*/
void bspSDRAMInit_Cpu192MHz_Sdram192MHz(){
    unsigned int val = 0;
    EMIF_Config MyConfig = {
        0x0020, /* egcr */ //ok
        0xFFFF, /* emirst */
        0x3FFF, /* ce01 */  //ok
        0x0000, /* ce02 */  //ok
        0x0000, /* ce03 */  //ok
        0x3FFF, /* ce11 */  //ok
        0x0000, /* ce12 */  //ok
        0x0000, /* ce13 */  //ok
        0x3FFF, /* ce21 */  //ok
        0x0000, /* ce22 */  //ok
        0x0000, /* ce23 */  //ok
        0x3FFF, /* ce31 */  //ok
        0x0000, /* ce32 */  //ok
        0x0000, /* ce33 */  //ok
        /*TRC: 65ns*132M  - 1= 8.58 - 1 = 7.58
        TRCD: 20ns*132M -1 = 2.64 -1 = 1.64
        TRP: 20ns*132M -1 = 2.64 - 1 = 1.64
        TMRD: 2-1 =1
        TRAS:  45ns*132M- 1 = 5.94 - 1 =4.94
        TACTV2ACTV = tRRD: 15n*132M - 1 = 0.98
        */
        0x4522, /* sdc1 */  //0x4522 ok;  0x3522 OK; 0x2522(err) 0x1d22
        0x0b00, /* sdper */  //ok??  0x0750 for 132Mhz
        0x07FF, /* init */
        0x0151 /* sdc2 */   //ok
    };

    EBSR = 0x281;
    //set div1 = 1, required when SDRAM CLK = CPU CLK
    EMIF_RSET(SDC3, 0x7);

    EMIF_config(&MyConfig);

}
