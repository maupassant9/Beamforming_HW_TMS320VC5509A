
/*
* FileName:
* Author: Dong Xia
* This is head file of
*
* Change Records:
*      >> (05/05/2021): Creation of file
*
*/

#ifndef SOURCES_BSP_SDRAM_SDRAM_H_
#define SOURCES_BSP_SDRAM_SDRAM_H_

/********************************************
* Include
********************************************/


/********************************************
* Macro
********************************************/
/*============================================================================*\
* _EMIF_SDC2:  SDRAM Control Register 2
\*============================================================================*/
#define _EMIF_SDC3_ADDR           (0x0814u)
#define _EMIF_SDC3                    PREG16(_EMIF_SDC3_ADDR)
#define _SDC3                       _EMIF_SDC3

/********************************************
* Type definition
********************************************/


/********************************************
* Function prototype
********************************************/
void bspSDRAMInit_Cpu192MHz_Sdram96MHz();
void bspSDRAMInit_Cpu200MHz_Sdram100MHz();
void bspSDRAMInit_Cpu192MHz_Sdram192MHz();








#endif /* SOURCES_BSP_SDRAM_SDRAM_H_ */
