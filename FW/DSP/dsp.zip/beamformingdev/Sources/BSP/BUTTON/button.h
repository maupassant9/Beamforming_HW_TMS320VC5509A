/*
* button.h
* Author: Dong Xia
* Abstraction for buttons used on board
*
* Change Records:
*      >> (03/05/2021): created
*
*/



#ifndef SOURCES_BSP_BUTTON_BUTTON_H_
#define SOURCES_BSP_BUTTON_BUTTON_H_
/********************************************
* Include
********************************************/
#include "../beamformType.h"

/********************************************
* Macro
********************************************/
//number of butons
#define BUTTON_NO 1

//defines the short pressed minimun time ticks number
//and the the long pressed minimun time ticks number
#define SHT_PRESSED_TICKS 5
#define LONG_PRESSED_TICKS 10

//maximum no of history state of a button
#define MAX_HISTORY_STATE 2

/********************************************
* Type definition
********************************************/
enum buttonPressedType_t {
    BUTTON_NOT_PRESSED = 0,
    BUTTON_SHT_PRESSED,
    BUTTON_LNG_PRESSED
};

/********************************************
* Function prototype
********************************************/
void bspButtonInit();










#endif /* SOURCES_BSP_BUTTON_BUTTON_H_ */
