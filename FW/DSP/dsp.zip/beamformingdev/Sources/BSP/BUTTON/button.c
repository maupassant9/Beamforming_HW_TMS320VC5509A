/*
* button.c
* Author: Dong Xia
* Abstraction for buttons with long pressed and
* short pressed functionality
*
* Change Records:
*      >> (03/05/2021):
*
*/

/********************************************
* Include
********************************************/
#include <stdbool.h>
#include "button.h"


/********************************************
* Internal Function Declaration
********************************************/
#if (SHT_PRESSED_TICKS >= LONG_PRESSED_TICKS)
#error SHT_PRESSED_TICKS should be less than LONG_PRESSED_TICKS
#endif


#if (MAX_HISTORY_STATE > 512)
#error MAX_HISTORY_STATE should be less than 512
#endif

static enum buttonPressedType_t hwButtonGetState(uint8_t buttonID);

/********************************************
* Internal Types and Variables
********************************************/
typedef struct{
    //a cnter for counting time ticks
    uint32_t cnter;

    //number of state saved in buffer
    uint8_t stateNo;
    enum buttonPressedType_t statesBuffer[MAX_HISTORY_STATE];

    //mark if it is in a detected cycle
    bool isDetected;

}button_t;

button_t buttonArray[BUTTON_NO];
/********************************************
* External Variables
********************************************/


/********************************************
* Functions
********************************************/
/*------------------------------------------------
* bspButtonInit();
* Init the button structure
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (03/05/2021): Create the function
*----------------------------------------------*/
void bspButtonInit(){

}


/*------------------------------------------------
* bspButtonUpdate();
* Update the button in a periodic time tick isr
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (03/05/2021): Create the function
*----------------------------------------------*/
void bspButtonUpdate(uint8_t buttonID){
    enum buttonPressedType_t state = hwButtonGetState(buttonID);
    button_t button = buttonArray[buttonID];
    uint32_t prevCnt = 0;

    //update the state into history state when:
    //1. state = NO_BUTTON_PRESSED, cnt == LONG_PRESSED_TICKS:  a long button pressed state detected
    //2. state = NO_BUTTON_PRESSED, cnt >= SHT_BUTTON_PRESSED: a short button pressed
    //3. state = NO_BUTTON_PRESSED, cnt < SHT_BUTTON_PRESSED: no button pressed
    //3. state = NO_BUTTON_PRESSED, cnt > LNG_BUTTON_PRESSED: ignore, already saved in history

    //4. state = SHT_BUTTON_PRESSED, cnt++: more time to check
    //5. state = SHT_BUTTON_PRESSED, cnt++: more time to check
    //6. state = SHT_BUTTON_PRESSED, cnt++; cnt == LNG_BUTTON_PRESSED:  a long button pressed state detected
    //7. state = SHT_BUTTON_PRESSED, cnt > LNG_BUTTON_PRESSED: ignore, already saved in history

    if( state == BUTTON_SHT_PRESSED){
        button.cnter++;
    } else if(state == BUTTON_NOT_PRESSED){
        if((button.cnter >= SHT_PRESSED_TICKS)&&(button.cnter < LONG_PRESSED_TICKS)){
            //add a short button pressed
        }

    }

    if(button.cnter == LONG_PRESSED_TICKS){
       //add a long button pressed state
    }

    //update the cnt
    if(state == BUTTON_NOT_PRESSED) button.cnter == 0;
}

/*------------------------------------------------
* bspButtonRemoveAllState
* Clear all the history state in buffer
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (03/05/2021): Create the function
*----------------------------------------------*/
void bspButtonRemoveAllState(){

}
/*------------------------------------------------
* bspButtonGetOldestState();
* Get the oldest updated state of the button
* Remove only this state from the state buffer,
* This is used when the oldest state
* has the highest priority
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (03/05/2021): Create the function
*----------------------------------------------*/
enum buttonPressedType_t bspButtonGetOldestState(){

}


/*------------------------------------------------
* bspButtonGetNewestState
* Get the newly updated state of the button
* Remove only the newest history state, this
* is used when the newest state has the
* highest priority
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (03/05/2021): Create the function
*----------------------------------------------*/
enum buttonPressedType_t bspButtonGetNewestState(){

}

/*------------------------------------------------
* bspButtonPeekState
* Peek a button state using id
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (03/05/2021): Create the function
*----------------------------------------------*/
static enum buttonPressedType_t bspButtonPeekState(uint8_t id){


}


/*------------------------------------------------
* hwButtonGetState
* Get the instantaneous button state directly from
* Hardware.
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (03/05/2021): Create the function
*----------------------------------------------*/
static enum buttonPressedType_t hwButtonGetState(uint8_t buttonID){

}

/*------------------------------------------------
* hwButtonGPIOInit();
* Init the button gpios
* Paras:
*  >> :
*  >> :
* Return:
*  >>
* Change Records:
*  >> (03/05/2021): Create the function
*----------------------------------------------*/

