/*
 * Copyright (C) 2004 Texas Instruments Incorporated
 * All Rights Reserved
 *
 *
 *---------read_write.c---------
 * This example does a write to the MMC/SD card and reads the
 * data written to verify the transfer.
 * This example is written for c5509. To run on c5509a, link in the
 * c5509a CSL library and define CHIP_5509A in the build options
 */
#include <csl.h>
#include <csl_mmc.h>
//#include "com.h"
#include "sd.h"
#include "..\FastFat\fat.h"

 #define DevNum 1
 #define ClusterAddr2SectorAddr(N)  (N-2)*SEC_PER_CLU + FIRST_DATA_SEC

//#pragma DATA_SECTION(mmc0,"cslmem")
MMC_Handle mmc0;


int count, retVal;
Uint16 rca;
Uint16 cardtype;
extern unsigned int card_rca;


  
bool_dt SdInit()
{

  IRQ_globalDisable();

  /*Configure the MMC register */
  mmc0 = MMC_open(MMC_DEV0);
 

 /*Configure the MMC register */
  CardInit();
  
  CardIdentify();
 
  SetTransMod();

  //Set CPU CLK = 100M
  //PLL_setFreq(5,2);  //CPU Clock = InputClock * 5 = 20M * 2.5 = 50M


  IRQ_globalEnable();

  return ISTRUE;  
 
}

//写一个扇区
bool_dt SdWriteSector(ulong_dt sector_addr_ul, uint_dt * data_ptr_uc)
{
    WriteDataToCard(card_rca,
                   ((sector_addr_ul&0xffff0000)>>16),
                   (sector_addr_ul&0xffff),
                    data_ptr_uc); 
	return ISTRUE;
}

//读一个扇区
bool_dt SdReadSector(ulong_dt sector_addr_ul,uint_dt * data_ptr_uc)
{
    ReadDataFromCard(card_rca,
                    ((sector_addr_ul&0xffff0000)>>16),
                    (sector_addr_ul&0xffff),
                     data_ptr_uc);
	return ISTRUE;
}

//获取实时时间日期信息，并转换为与FAT目录项中的时间日期格式
ulong_dt DataTime(void)
{
	return 0x1076893a;
}

void DiskInit()
{
    SdInit();
}
    

void ReadSector(ulong_dt sector_addr_ul,uint_dt * data_ptr_uc)
{
    SdReadSector(sector_addr_ul,data_ptr_uc);
}


void WriteSector(ulong_dt sector_addr_ul,uint_dt * data_ptr_uc)
{
    SdWriteSector(sector_addr_ul,data_ptr_uc);
}


void WriteCluster(ulong_dt cluster_addr,uint_dt * data_ptr_uc)
{
    ulong_dt temp = ClusterAddr2SectorAddr(cluster_addr);
    WriteMultipleDataToCard(card_rca,
                    ((temp&0xffff0000)>>16),
                    (temp&0xffff),
                     data_ptr_uc,
                     SEC_PER_CLU);
}
