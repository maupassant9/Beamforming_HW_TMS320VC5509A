/*
* PeripheralScanner.c
* Author: Dong Xia
* PeripheralScanner scans the buttons and set the LED
* states according to the led and button configuration
* set by user.
*
* Change Records:
*      >> (02/05/2021): created
*
*
*/

/********************************************
* Include
********************************************/
#include <std.h>
#include "../Sources/BSP/LED/led.h"

/********************************************
* Internal Function Declaration
********************************************/



/********************************************
* Internal Types and Variables
********************************************/

/********************************************
* External Variables
********************************************/


/********************************************
* Functions
********************************************/
Void periodScanner(void ){
    //update the led state
    bspLedUpdateAll();
    //update the button state

}




